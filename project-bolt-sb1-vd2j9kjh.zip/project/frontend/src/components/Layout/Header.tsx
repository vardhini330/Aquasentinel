import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  BellIcon, 
  UserIcon, 
  ChevronDownIcon,
  ArrowRightOnRectangleIcon,
  LanguageIcon
} from '@heroicons/react/24/outline';
import { useAuthStore } from '../../stores/authStore';
import { useNotificationStore } from '../../stores/notificationStore';
import { useTranslation } from '../../hooks/useTranslation';

const Header: React.FC = () => {
  const { user, logout } = useAuthStore();
  const { unreadCount } = useNotificationStore();
  const { language, setLanguage, t } = useTranslation();
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showLangMenu, setShowLangMenu] = useState(false);

  const handleLogout = () => {
    logout();
  };

  const toggleLanguage = (newLang: 'en' | 'hi') => {
    setLanguage(newLang);
    setShowLangMenu(false);
  };

  return (
    <header className="bg-white border-b border-gray-200 shadow-sm">
      <div className="max-w-full px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo and Title */}
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <img
                src="/assets/jharkhand_logo.png"
                alt="Jharkhand Government"
                className="h-10 w-10"
                onError={(e) => {
                  // Fallback to text if image not found
                  (e.target as HTMLImageElement).style.display = 'none';
                }}
              />
              <div 
                className="h-10 w-10 bg-primary rounded-full flex items-center justify-center text-white font-bold"
                style={{ display: 'none' }}
                onLoad={(e) => {
                  (e.target as HTMLElement).style.display = 'flex';
                }}
              >
                JH
              </div>
            </div>
            <div className="ml-3">
              <h1 className="text-lg font-semibold text-gray-900">
                {t('header.title')}
              </h1>
              <p className="text-xs text-gray-500">
                {t('header.subtitle')}
              </p>
            </div>
          </div>

          {/* User Info and Actions */}
          <div className="flex items-center space-x-4">
            {/* Language Selector */}
            <div className="relative">
              <button
                onClick={() => setShowLangMenu(!showLangMenu)}
                className="flex items-center space-x-1 px-3 py-2 text-sm font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50 rounded-md transition-colors"
              >
                <LanguageIcon className="h-4 w-4" />
                <span>{language === 'en' ? 'EN' : 'हि'}</span>
                <ChevronDownIcon className="h-3 w-3" />
              </button>

              {showLangMenu && (
                <div className="absolute right-0 z-50 mt-2 w-32 bg-white rounded-md shadow-lg border border-gray-200">
                  <div className="py-1">
                    <button
                      onClick={() => toggleLanguage('en')}
                      className={`block w-full text-left px-4 py-2 text-sm hover:bg-gray-50 ${
                        language === 'en' ? 'text-primary font-medium' : 'text-gray-700'
                      }`}
                    >
                      English
                    </button>
                    <button
                      onClick={() => toggleLanguage('hi')}
                      className={`block w-full text-left px-4 py-2 text-sm hover:bg-gray-50 ${
                        language === 'hi' ? 'text-primary font-medium' : 'text-gray-700'
                      }`}
                    >
                      हिन्दी
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Notifications */}
            <Link
              to="/notifications"
              className="relative p-2 text-gray-600 hover:text-gray-900 hover:bg-gray-50 rounded-md transition-colors"
            >
              <BellIcon className="h-5 w-5" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 h-5 w-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                  {unreadCount > 99 ? '99+' : unreadCount}
                </span>
              )}
            </Link>

            {/* User Menu */}
            <div className="relative">
              <button
                onClick={() => setShowUserMenu(!showUserMenu)}
                className="flex items-center space-x-3 px-3 py-2 text-sm font-medium text-gray-700 hover:text-gray-900 hover:bg-gray-50 rounded-md transition-colors"
              >
                <div className="h-8 w-8 bg-primary-100 rounded-full flex items-center justify-center">
                  <UserIcon className="h-4 w-4 text-primary" />
                </div>
                <div className="text-left hidden sm:block">
                  <div className="font-medium text-gray-900">{user?.name}</div>
                  <div className="text-xs text-gray-500 capitalize">
                    {user?.role.toLowerCase().replace('_', ' ')}
                  </div>
                </div>
                <ChevronDownIcon className="h-4 w-4" />
              </button>

              {showUserMenu && (
                <div className="absolute right-0 z-50 mt-2 w-56 bg-white rounded-md shadow-lg border border-gray-200">
                  <div className="px-4 py-3 border-b border-gray-100">
                    <p className="text-sm font-medium text-gray-900">{user?.name}</p>
                    <p className="text-sm text-gray-500">{user?.email}</p>
                    {user?.department && (
                      <p className="text-xs text-gray-400 mt-1">
                        {user.department.name}
                      </p>
                    )}
                  </div>
                  
                  <div className="py-1">
                    <button
                      onClick={handleLogout}
                      className="flex w-full items-center px-4 py-2 text-sm text-gray-700 hover:bg-gray-50"
                    >
                      <ArrowRightOnRectangleIcon className="h-4 w-4 mr-3" />
                      {t('common.logout')}
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Close dropdowns when clicking outside */}
      {(showUserMenu || showLangMenu) && (
        <div
          className="fixed inset-0 z-40"
          onClick={() => {
            setShowUserMenu(false);
            setShowLangMenu(false);
          }}
        />
      )}
    </header>
  );
};

export default Header;