import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { api } from '../services/api';
import toast from 'react-hot-toast';

export interface User {
  id: number;
  name: string;
  email: string;
  role: 'SUPER_ADMIN' | 'DEPT_OFFICER' | 'FIELD_OFFICER';
  department?: {
    id: number;
    name: string;
    code: string;
  };
}

interface AuthState {
  user: User | null;
  token: string | null;
  refreshToken: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

interface AuthActions {
  login: (email: string, password: string, rememberMe?: boolean) => Promise<void>;
  logout: () => void;
  refreshAuth: () => Promise<void>;
  setLoading: (loading: boolean) => void;
  initialize: () => Promise<void>;
}

export const useAuthStore = create<AuthState & AuthActions>()(
  persist(
    (set, get) => ({
      user: null,
      token: null,
      refreshToken: null,
      isAuthenticated: false,
      isLoading: true,

      login: async (email: string, password: string, rememberMe = false) => {
        try {
          set({ isLoading: true });
          
          const response = await api.post('/auth/login', {
            email,
            password,
            rememberMe
          });

          const { accessToken, refreshToken: newRefreshToken, user } = response.data;

          set({
            user,
            token: accessToken,
            refreshToken: newRefreshToken,
            isAuthenticated: true,
            isLoading: false
          });

          // Set token in API client
          api.defaults.headers.common['Authorization'] = `Bearer ${accessToken}`;

          toast.success(`Welcome back, ${user.name}!`);
        } catch (error: any) {
          set({ isLoading: false });
          const message = error.response?.data?.error || 'Login failed';
          toast.error(message);
          throw error;
        }
      },

      logout: () => {
        set({
          user: null,
          token: null,
          refreshToken: null,
          isAuthenticated: false,
          isLoading: false
        });

        // Remove token from API client
        delete api.defaults.headers.common['Authorization'];

        toast.success('Logged out successfully');
      },

      refreshAuth: async () => {
        try {
          const { refreshToken } = get();
          if (!refreshToken) {
            throw new Error('No refresh token available');
          }

          const response = await api.post('/auth/refresh', {
            refreshToken
          });

          const { accessToken } = response.data;

          set({ token: accessToken });
          api.defaults.headers.common['Authorization'] = `Bearer ${accessToken}`;
        } catch (error) {
          // Refresh failed, logout user
          get().logout();
          throw error;
        }
      },

      setLoading: (loading: boolean) => {
        set({ isLoading: loading });
      },

      initialize: async () => {
        const { token, refreshToken } = get();
        
        if (!token) {
          set({ isLoading: false });
          return;
        }

        try {
          // Set token in API client
          api.defaults.headers.common['Authorization'] = `Bearer ${token}`;

          // Verify token by fetching user profile
          const response = await api.get('/auth/me');
          
          set({
            user: response.data,
            isAuthenticated: true,
            isLoading: false
          });
        } catch (error) {
          // Token is invalid, try to refresh
          if (refreshToken) {
            try {
              await get().refreshAuth();
              
              // Retry getting user profile
              const response = await api.get('/auth/me');
              
              set({
                user: response.data,
                isAuthenticated: true,
                isLoading: false
              });
            } catch (refreshError) {
              // Refresh also failed, logout
              get().logout();
            }
          } else {
            // No refresh token, logout
            get().logout();
          }
        }
      }
    }),
    {
      name: 'auth-storage',
      partialize: (state) => ({
        token: state.token,
        refreshToken: state.refreshToken,
        user: state.user
      })
    }
  )
);

// Auto-refresh token before expiration
let refreshTimer: NodeJS.Timeout;

const scheduleTokenRefresh = () => {
  const { token, refreshAuth } = useAuthStore.getState();
  
  if (!token) return;

  // Decode JWT to get expiration time (simplified)
  try {
    const payload = JSON.parse(atob(token.split('.')[1]));
    const expiresAt = payload.exp * 1000;
    const now = Date.now();
    const timeUntilExpiry = expiresAt - now;
    
    // Refresh 5 minutes before expiration
    const refreshTime = Math.max(0, timeUntilExpiry - 5 * 60 * 1000);
    
    clearTimeout(refreshTimer);
    refreshTimer = setTimeout(async () => {
      try {
        await refreshAuth();
        scheduleTokenRefresh(); // Schedule next refresh
      } catch (error) {
        console.error('Token refresh failed:', error);
      }
    }, refreshTime);
  } catch (error) {
    console.error('Token parsing failed:', error);
  }
};

// Initialize auth store
useAuthStore.getState().initialize().then(() => {
  scheduleTokenRefresh();
});