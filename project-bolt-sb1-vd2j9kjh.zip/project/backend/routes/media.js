const express = require('express');
const multer = require('multer');
const sharp = require('sharp');
const path = require('path');
const fs = require('fs').promises;
const { authenticateToken } = require('../middleware/auth');
const { getDb } = require('../config/database');

const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: async (req, file, cb) => {
    const uploadDir = 'uploads';
    try {
      await fs.access(uploadDir);
    } catch {
      await fs.mkdir(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 50 * 1024 * 1024 // 50MB limit
  },
  fileFilter: (req, file, cb) => {
    // Allow images and audio files
    const allowedTypes = /jpeg|jpg|png|gif|mp3|wav|m4a|webm|ogg/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);

    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Only image and audio files are allowed'));
    }
  }
});

// Upload media files for a ticket
router.post('/upload/:ticketId', authenticateToken, upload.array('media', 10), async (req, res) => {
  try {
    const ticketId = req.params.ticketId;
    const files = req.files;

    if (!files || files.length === 0) {
      return res.status(400).json({ error: 'No files uploaded' });
    }

    const db = getDb();

    // Verify ticket exists and user has access
    const ticketResult = await db.query('SELECT * FROM tickets WHERE id = $1', [ticketId]);
    
    if (ticketResult.rows.length === 0) {
      return res.status(404).json({ error: 'Ticket not found' });
    }

    const ticket = ticketResult.rows[0];

    // Authorization check
    if (req.user.role === 'DEPT_OFFICER' && ticket.department_id !== req.user.department_id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    const mediaRecords = [];

    for (const file of files) {
      let processedPath = file.path;
      let thumbnailPath = null;

      // Process images
      if (file.mimetype.startsWith('image/')) {
        // Create thumbnail for images
        const thumbnailDir = 'uploads/thumbnails';
        try {
          await fs.access(thumbnailDir);
        } catch {
          await fs.mkdir(thumbnailDir, { recursive: true });
        }

        thumbnailPath = path.join(thumbnailDir, 'thumb_' + file.filename);
        
        await sharp(file.path)
          .resize(200, 200, { fit: 'cover' })
          .jpeg({ quality: 80 })
          .toFile(thumbnailPath);

        // Optimize original image
        const optimizedPath = 'uploads/opt_' + file.filename;
        await sharp(file.path)
          .resize(1200, 1200, { fit: 'inside', withoutEnlargement: true })
          .jpeg({ quality: 85 })
          .toFile(optimizedPath);
        
        // Replace original with optimized
        await fs.unlink(file.path);
        await fs.rename(optimizedPath, file.path);
      }

      // Insert media record
      const mediaResult = await db.query(`
        INSERT INTO media (ticket_id, filename, original_name, url, thumbnail_url, type, size, mime_type, created_at)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, NOW())
        RETURNING *
      `, [
        ticketId,
        file.filename,
        file.originalname,
        `/uploads/${file.filename}`,
        thumbnailPath ? `/uploads/thumbnails/thumb_${file.filename}` : null,
        file.mimetype.startsWith('image/') ? 'IMAGE' : 'AUDIO',
        file.size,
        file.mimetype
      ]);

      mediaRecords.push(mediaResult.rows[0]);
    }

    res.json({
      message: `${files.length} files uploaded successfully`,
      media: mediaRecords
    });
  } catch (error) {
    console.error('Upload media error:', error);
    res.status(500).json({ error: 'Failed to upload media files' });
  }
});

// Get media file
router.get('/file/:filename', (req, res) => {
  try {
    const filename = req.params.filename;
    const filePath = path.join('uploads', filename);
    
    res.sendFile(path.resolve(filePath), (err) => {
      if (err) {
        console.error('File serve error:', err);
        res.status(404).json({ error: 'File not found' });
      }
    });
  } catch (error) {
    console.error('Get media file error:', error);
    res.status(500).json({ error: 'Failed to serve media file' });
  }
});

// Get thumbnail
router.get('/thumbnail/:filename', (req, res) => {
  try {
    const filename = req.params.filename;
    const thumbnailPath = path.join('uploads', 'thumbnails', filename);
    
    res.sendFile(path.resolve(thumbnailPath), (err) => {
      if (err) {
        console.error('Thumbnail serve error:', err);
        res.status(404).json({ error: 'Thumbnail not found' });
      }
    });
  } catch (error) {
    console.error('Get thumbnail error:', error);
    res.status(500).json({ error: 'Failed to serve thumbnail' });
  }
});

// Delete media file
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    const mediaId = req.params.id;
    const db = getDb();

    // Get media record with ticket info
    const mediaResult = await db.query(`
      SELECT m.*, t.department_id 
      FROM media m
      JOIN tickets t ON m.ticket_id = t.id
      WHERE m.id = $1
    `, [mediaId]);

    if (mediaResult.rows.length === 0) {
      return res.status(404).json({ error: 'Media not found' });
    }

    const media = mediaResult.rows[0];

    // Authorization check
    if (req.user.role === 'DEPT_OFFICER' && media.department_id !== req.user.department_id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    // Delete files from filesystem
    try {
      await fs.unlink(path.join('uploads', media.filename));
      if (media.thumbnail_url) {
        await fs.unlink(path.join('uploads', 'thumbnails', `thumb_${media.filename}`));
      }
    } catch (fileError) {
      console.error('File deletion error:', fileError);
      // Continue with database deletion even if file deletion fails
    }

    // Delete from database
    await db.query('DELETE FROM media WHERE id = $1', [mediaId]);

    res.json({ message: 'Media file deleted successfully' });
  } catch (error) {
    console.error('Delete media error:', error);
    res.status(500).json({ error: 'Failed to delete media file' });
  }
});

// Get ticket media
router.get('/ticket/:ticketId', authenticateToken, async (req, res) => {
  try {
    const ticketId = req.params.ticketId;
    const db = getDb();

    // Get media with authorization check
    const result = await db.query(`
      SELECT m.*, t.department_id 
      FROM media m
      JOIN tickets t ON m.ticket_id = t.id
      WHERE m.ticket_id = $1
      ORDER BY m.created_at
    `, [ticketId]);

    // Authorization check for first record (all will have same department)
    if (result.rows.length > 0) {
      const departmentId = result.rows[0].department_id;
      if (req.user.role === 'DEPT_OFFICER' && departmentId !== req.user.department_id) {
        return res.status(403).json({ error: 'Access denied' });
      }
    }

    res.json(result.rows);
  } catch (error) {
    console.error('Get ticket media error:', error);
    res.status(500).json({ error: 'Failed to fetch ticket media' });
  }
});

module.exports = router;