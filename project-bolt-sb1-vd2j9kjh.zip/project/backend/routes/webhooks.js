const express = require('express');
const { getDb } = require('../config/database');
const { broadcastTicketUpdate } = require('../websocket/handler');

const router = express.Router();

// Webhook for incoming messages (WhatsApp, SMS, etc.)
router.post('/incoming', async (req, res) => {
  try {
    const { source, message, phone, media_url, lat, lng } = req.body;
    
    console.log('Received webhook:', { source, message, phone });

    // Simple message processing - in real implementation, you'd use NLP/AI
    const category = extractCategory(message);
    const priority = extractPriority(message);
    
    if (!category) {
      return res.json({ 
        success: true, 
        message: 'Message received but could not determine category' 
      });
    }

    const db = getDb();
    
    // Get department
    const deptResult = await db.query(
      'SELECT id FROM departments WHERE code = $1',
      [category]
    );

    if (deptResult.rows.length === 0) {
      return res.json({ 
        success: true, 
        message: 'Unknown category, ticket not created' 
      });
    }

    const departmentId = deptResult.rows[0].id;

    // Find panchayat (fallback to first if no coordinates)
    let panchayatId = 1;
    if (lat && lng) {
      const panchayatResult = await db.query(`
        SELECT id FROM panchayats 
        ORDER BY (lat - $1)^2 + (lng - $2)^2 
        LIMIT 1
      `, [lat, lng]);
      panchayatId = panchayatResult.rows[0]?.id || 1;
    }

    // Generate ticket number
    const ticketNo = `WH${Date.now().toString().slice(-8)}`;

    // Calculate SLA due date
    const slaDue = new Date();
    slaDue.setHours(slaDue.getHours() + (priority === 'CRITICAL' ? 4 : 24));

    // Create ticket
    const insertResult = await db.query(`
      INSERT INTO tickets (
        ticket_no, category, description, lat, lng, priority,
        citizen_phone, department_id, panchayat_id, 
        status, sla_due, source, created_at, updated_at
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, $9, 'PENDING', $10, $11, NOW(), NOW()
      ) RETURNING *
    `, [
      ticketNo, category, message, lat || 0, lng || 0, priority,
      phone, departmentId, panchayatId, slaDue, source || 'WEBHOOK'
    ]);

    const ticket = insertResult.rows[0];

    // Add media if provided
    if (media_url) {
      await db.query(
        'INSERT INTO media (ticket_id, url, type, created_at) VALUES ($1, $2, $3, NOW())',
        [ticket.id, media_url, 'IMAGE']
      );
    }

    // Add to history
    await db.query(`
      INSERT INTO ticket_history (ticket_id, from_status, to_status, comment, created_at)
      VALUES ($1, NULL, 'PENDING', $2, NOW())
    `, [ticket.id, `Ticket created from ${source || 'webhook'}`]);

    // Broadcast update
    const eventData = {
      event: 'ticket.created',
      ticket: {
        id: ticket.id,
        ticket_no: ticket.ticket_no,
        category: ticket.category,
        lat: ticket.lat,
        lng: ticket.lng,
        department_id: ticket.department_id,
        panchayat_id: ticket.panchayat_id,
        priority: ticket.priority,
        status: ticket.status,
        source: ticket.source,
        created_at: ticket.created_at
      }
    };

    broadcastTicketUpdate(`dept:${departmentId}`, eventData);
    broadcastTicketUpdate(`panchayat:${panchayatId}`, eventData);

    res.json({ 
      success: true, 
      message: 'Ticket created successfully',
      ticket_no: ticket.ticket_no
    });
  } catch (error) {
    console.error('Webhook processing error:', error);
    res.status(500).json({ error: 'Failed to process webhook' });
  }
});

// Health check for webhook endpoint
router.get('/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    endpoint: 'webhooks',
    timestamp: new Date().toISOString() 
  });
});

// Helper functions
function extractCategory(message) {
  const text = message.toLowerCase();
  
  if (text.includes('road') || text.includes('pothole') || text.includes('street')) {
    return 'ROADS';
  }
  if (text.includes('light') || text.includes('electricity') || text.includes('power')) {
    return 'ELECTRICITY';
  }
  if (text.includes('garbage') || text.includes('waste') || text.includes('toilet')) {
    return 'SANITATION';
  }
  if (text.includes('water') || text.includes('tap') || text.includes('supply')) {
    return 'WATER';
  }
  if (text.includes('park') || text.includes('garden') || text.includes('tree')) {
    return 'PARKS';
  }
  
  return 'GENERAL'; // Default category
}

function extractPriority(message) {
  const text = message.toLowerCase();
  
  if (text.includes('urgent') || text.includes('emergency') || text.includes('critical')) {
    return 'CRITICAL';
  }
  if (text.includes('important') || text.includes('high')) {
    return 'HIGH';
  }
  if (text.includes('low') || text.includes('minor')) {
    return 'LOW';
  }
  
  return 'MEDIUM'; // Default priority
}

module.exports = router;