const WebSocket = require('ws');
const jwt = require('jsonwebtoken');
const { getRedisSubscriber, getRedisPublisher } = require('../config/redis');

let wss;
const connections = new Map(); // userId -> WebSocket connection
const subscriptions = new Map(); // connectionId -> Set of channels

const setupWebSocket = (server) => {
  wss = new WebSocket.Server({ 
    server,
    path: '/ws',
    verifyClient: (info) => {
      try {
        const token = new URL(info.req.url, 'http://localhost').searchParams.get('token');
        if (!token) return false;
        
        jwt.verify(token, process.env.JWT_SECRET);
        return true;
      } catch {
        return false;
      }
    }
  });

  wss.on('connection', async (ws, req) => {
    try {
      const url = new URL(req.url, 'http://localhost');
      const token = url.searchParams.get('token');
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      
      const connectionId = `${decoded.userId}_${Date.now()}`;
      ws.userId = decoded.userId;
      ws.role = decoded.role;
      ws.departmentId = decoded.departmentId;
      ws.connectionId = connectionId;
      
      connections.set(connectionId, ws);
      subscriptions.set(connectionId, new Set());
      
      console.log(`WebSocket connected: User ${decoded.userId}, Role: ${decoded.role}`);
      
      // Subscribe to user-specific notifications
      subscriptions.get(connectionId).add(`user:${decoded.userId}`);
      
      // Auto-subscribe based on role
      if (decoded.role === 'DEPT_OFFICER' && decoded.departmentId) {
        subscriptions.get(connectionId).add(`dept:${decoded.departmentId}`);
      }
      
      ws.send(JSON.stringify({
        type: 'connected',
        message: 'WebSocket connection established',
        subscriptions: Array.from(subscriptions.get(connectionId))
      }));

      ws.on('message', async (data) => {
        try {
          const message = JSON.parse(data);
          await handleWebSocketMessage(ws, message);
        } catch (error) {
          console.error('WebSocket message error:', error);
          ws.send(JSON.stringify({
            type: 'error',
            message: 'Invalid message format'
          }));
        }
      });

      ws.on('close', () => {
        console.log(`WebSocket disconnected: User ${decoded.userId}`);
        connections.delete(connectionId);
        subscriptions.delete(connectionId);
      });

      ws.on('error', (error) => {
        console.error('WebSocket error:', error);
        connections.delete(connectionId);
        subscriptions.delete(connectionId);
      });

    } catch (error) {
      console.error('WebSocket setup error:', error);
      ws.close();
    }
  });

  // Setup Redis subscription for broadcasting
  setupRedisSubscription();
  
  console.log('✅ WebSocket server setup complete');
};

const handleWebSocketMessage = async (ws, message) => {
  const { type, payload } = message;

  switch (type) {
    case 'subscribe':
      handleSubscription(ws, payload.channels);
      break;
      
    case 'unsubscribe':
      handleUnsubscription(ws, payload.channels);
      break;
      
    case 'ping':
      ws.send(JSON.stringify({ type: 'pong', timestamp: Date.now() }));
      break;
      
    default:
      ws.send(JSON.stringify({
        type: 'error',
        message: `Unknown message type: ${type}`
      }));
  }
};

const handleSubscription = (ws, channels) => {
  const userSubscriptions = subscriptions.get(ws.connectionId);
  
  for (const channel of channels) {
    // Authorization checks for channel subscriptions
    if (channel.startsWith('dept:')) {
      const deptId = parseInt(channel.split(':')[1]);
      if (ws.role === 'DEPT_OFFICER' && ws.departmentId !== deptId) {
        continue; // Skip unauthorized department
      }
      if (ws.role === 'FIELD_OFFICER') {
        continue; // Field officers can't subscribe to department channels
      }
    } else if (channel.startsWith('panchayat:')) {
      // For now, allow all authenticated users to subscribe to panchayat updates
      // In production, implement proper panchayat-based authorization
    } else if (channel.startsWith('user:')) {
      const userId = parseInt(channel.split(':')[1]);
      if (ws.userId !== userId) {
        continue; // Users can only subscribe to their own notifications
      }
    }
    
    userSubscriptions.add(channel);
  }
  
  ws.send(JSON.stringify({
    type: 'subscribed',
    subscriptions: Array.from(userSubscriptions)
  }));
};

const handleUnsubscription = (ws, channels) => {
  const userSubscriptions = subscriptions.get(ws.connectionId);
  
  for (const channel of channels) {
    userSubscriptions.delete(channel);
  }
  
  ws.send(JSON.stringify({
    type: 'unsubscribed',
    subscriptions: Array.from(userSubscriptions)
  }));
};

const setupRedisSubscription = async () => {
  try {
    const subscriber = getRedisSubscriber();
    
    // Subscribe to all broadcast channels
    await subscriber.pSubscribe('broadcast:*');
    
    subscriber.on('pmessage', (pattern, channel, message) => {
      try {
        const data = JSON.parse(message);
        const targetChannel = channel.replace('broadcast:', '');
        
        // Find connections subscribed to this channel
        for (const [connectionId, ws] of connections) {
          const userSubscriptions = subscriptions.get(connectionId);
          if (userSubscriptions && userSubscriptions.has(targetChannel)) {
            if (ws.readyState === WebSocket.OPEN) {
              ws.send(JSON.stringify(data));
            }
          }
        }
      } catch (error) {
        console.error('Redis message processing error:', error);
      }
    });
    
    console.log('✅ Redis WebSocket subscription setup complete');
  } catch (error) {
    console.error('Redis subscription setup error:', error);
  }
};

// Utility functions for broadcasting
const broadcastTicketUpdate = async (channel, data) => {
  try {
    const publisher = getRedisPublisher();
    await publisher.publish(`broadcast:${channel}`, JSON.stringify(data));
  } catch (error) {
    console.error('Broadcast ticket update error:', error);
  }
};

const broadcastNotification = async (userId, data) => {
  try {
    const publisher = getRedisPublisher();
    await publisher.publish(`broadcast:user:${userId}`, JSON.stringify(data));
  } catch (error) {
    console.error('Broadcast notification error:', error);
  }
};

const broadcastToAll = async (data) => {
  for (const [connectionId, ws] of connections) {
    if (ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(data));
    }
  }
};

module.exports = {
  setupWebSocket,
  broadcastTicketUpdate,
  broadcastNotification,
  broadcastToAll
};