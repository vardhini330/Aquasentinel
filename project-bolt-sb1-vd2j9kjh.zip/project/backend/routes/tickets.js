const express = require('express');
const Joi = require('joi');
const { v4: uuidv4 } = require('uuid');
const { getDb } = require('../config/database');
const { getRedisPublisher } = require('../config/redis');
const { authenticateToken, authorizeDepartment } = require('../middleware/auth');
const { broadcastTicketUpdate } = require('../websocket/handler');

const router = express.Router();

// Validation schemas
const createTicketSchema = Joi.object({
  category: Joi.string().valid('ROADS', 'ELECTRICITY', 'SANITATION', 'WATER', 'PARKS', 'GENERAL').required(),
  description: Joi.string().min(10).max(1000).required(),
  lat: Joi.number().min(-90).max(90).required(),
  lng: Joi.number().min(-180).max(180).required(),
  address: Joi.string().max(255).optional(),
  priority: Joi.string().valid('LOW', 'MEDIUM', 'HIGH', 'CRITICAL').default('MEDIUM'),
  citizen_name: Joi.string().max(100).optional(),
  citizen_phone: Joi.string().max(15).optional(),
  media_urls: Joi.array().items(Joi.string()).optional()
});

const updateStatusSchema = Joi.object({
  status: Joi.string().valid('PENDING', 'ACKNOWLEDGED', 'IN_PROGRESS', 'RESOLVED', 'VERIFIED', 'CLOSED').required(),
  comment: Joi.string().max(500).optional(),
  assigned_to: Joi.number().optional()
});

const assignTicketSchema = Joi.object({
  assigned_to: Joi.number().required(),
  comment: Joi.string().max(500).optional()
});

// Get tickets with filtering and pagination
router.get('/', authenticateToken, async (req, res) => {
  try {
    const { 
      departmentId, 
      panchayatId, 
      status, 
      priority,
      search,
      bbox, 
      from, 
      to, 
      page = 1, 
      limit = 20 
    } = req.query;

    const offset = (page - 1) * limit;
    const db = getDb();

    // Build dynamic query
    let query = `
      SELECT t.*, 
             d.name as department_name,
             p.name as panchayat_name, p.district,
             u.name as assigned_to_name,
             creator.name as creator_name
      FROM tickets t
      LEFT JOIN departments d ON t.department_id = d.id
      LEFT JOIN panchayats p ON t.panchayat_id = p.id
      LEFT JOIN users u ON t.assigned_to = u.id
      LEFT JOIN users creator ON t.created_by = creator.id
      WHERE 1=1
    `;

    const conditions = [];
    const params = [];
    let paramCount = 0;

    // Authorization check
    if (req.user.role === 'DEPT_OFFICER') {
      paramCount++;
      conditions.push(`t.department_id = $${paramCount}`);
      params.push(req.user.department_id);
    } else if (req.user.role === 'FIELD_OFFICER') {
      paramCount++;
      conditions.push(`t.assigned_to = $${paramCount}`);
      params.push(req.user.id);
    }

    // Apply filters
    if (departmentId) {
      paramCount++;
      conditions.push(`t.department_id = $${paramCount}`);
      params.push(departmentId);
    }

    if (panchayatId) {
      paramCount++;
      conditions.push(`t.panchayat_id = $${paramCount}`);
      params.push(panchayatId);
    }

    if (status) {
      paramCount++;
      conditions.push(`t.status = $${paramCount}`);
      params.push(status);
    }

    if (priority) {
      paramCount++;
      conditions.push(`t.priority = $${paramCount}`);
      params.push(priority);
    }

    if (search) {
      paramCount++;
      conditions.push(`(t.description ILIKE $${paramCount} OR t.ticket_no ILIKE $${paramCount})`);
      params.push(`%${search}%`);
    }

    if (from) {
      paramCount++;
      conditions.push(`t.created_at >= $${paramCount}`);
      params.push(from);
    }

    if (to) {
      paramCount++;
      conditions.push(`t.created_at <= $${paramCount}`);
      params.push(to);
    }

    if (bbox) {
      const [minLng, minLat, maxLng, maxLat] = bbox.split(',').map(Number);
      paramCount++;
      conditions.push(`t.lat BETWEEN $${paramCount} AND $${paramCount + 1}`);
      params.push(minLat, maxLat);
      paramCount += 2;
      conditions.push(`t.lng BETWEEN $${paramCount} AND $${paramCount + 1}`);
      params.push(minLng, maxLng);
      paramCount += 2;
    }

    if (conditions.length > 0) {
      query += ` AND ${conditions.join(' AND ')}`;
    }

    query += ` ORDER BY t.created_at DESC LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}`;
    params.push(limit, offset);

    const result = await db.query(query, params);

    // Get total count for pagination
    let countQuery = `
      SELECT COUNT(*) as total FROM tickets t WHERE 1=1
    `;
    
    if (conditions.length > 0) {
      countQuery += ` AND ${conditions.join(' AND ')}`;
    }

    const countResult = await db.query(countQuery, params.slice(0, -2)); // Remove limit and offset
    const total = parseInt(countResult.rows[0].total);

    res.json({
      tickets: result.rows,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Get tickets error:', error);
    res.status(500).json({ error: 'Failed to fetch tickets' });
  }
});

// Get single ticket by ID
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const db = getDb();
    const result = await db.query(`
      SELECT t.*, 
             d.name as department_name, d.code as department_code,
             p.name as panchayat_name, p.district,
             u.name as assigned_to_name, u.email as assigned_to_email,
             creator.name as creator_name
      FROM tickets t
      LEFT JOIN departments d ON t.department_id = d.id
      LEFT JOIN panchayats p ON t.panchayat_id = p.id
      LEFT JOIN users u ON t.assigned_to = u.id
      LEFT JOIN users creator ON t.created_by = creator.id
      WHERE t.id = $1
    `, [req.params.id]);

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Ticket not found' });
    }

    const ticket = result.rows[0];

    // Authorization check
    if (req.user.role === 'DEPT_OFFICER' && ticket.department_id !== req.user.department_id) {
      return res.status(403).json({ error: 'Access denied' });
    }
    
    if (req.user.role === 'FIELD_OFFICER' && ticket.assigned_to !== req.user.id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    // Get ticket history
    const historyResult = await db.query(`
      SELECT th.*, u.name as changed_by_name
      FROM ticket_history th
      LEFT JOIN users u ON th.changed_by = u.id
      WHERE th.ticket_id = $1
      ORDER BY th.created_at ASC
    `, [req.params.id]);

    // Get media files
    const mediaResult = await db.query(
      'SELECT * FROM media WHERE ticket_id = $1 ORDER BY created_at',
      [req.params.id]
    );

    res.json({
      ...ticket,
      history: historyResult.rows,
      media: mediaResult.rows
    });
  } catch (error) {
    console.error('Get ticket error:', error);
    res.status(500).json({ error: 'Failed to fetch ticket' });
  }
});

// Create new ticket (public endpoint)
router.post('/public', async (req, res) => {
  try {
    const { error } = createTicketSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }

    const {
      category,
      description,
      lat,
      lng,
      address,
      priority = 'MEDIUM',
      citizen_name,
      citizen_phone,
      media_urls = []
    } = req.body;

    const db = getDb();
    
    // Determine department based on category
    const deptResult = await db.query(
      'SELECT id FROM departments WHERE code = $1',
      [category]
    );

    if (deptResult.rows.length === 0) {
      return res.status(400).json({ error: 'Invalid category' });
    }

    const departmentId = deptResult.rows[0].id;

    // Find nearest panchayat (simplified - in real app would use PostGIS)
    const panchayatResult = await db.query(`
      SELECT id FROM panchayats 
      ORDER BY (lat - $1)^2 + (lng - $2)^2 
      LIMIT 1
    `, [lat, lng]);

    const panchayatId = panchayatResult.rows[0]?.id || 1; // Fallback to first panchayat

    // Generate ticket number
    const ticketNo = `JH${Date.now().toString().slice(-8)}`;

    // Calculate SLA due date (24 hours for now)
    const slaDue = new Date();
    slaDue.setHours(slaDue.getHours() + 24);

    // Insert ticket
    const insertResult = await db.query(`
      INSERT INTO tickets (
        ticket_no, category, description, lat, lng, address, priority,
        citizen_name, citizen_phone, department_id, panchayat_id, 
        status, sla_due, created_at, updated_at
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, 'PENDING', $12, NOW(), NOW()
      ) RETURNING *
    `, [
      ticketNo, category, description, lat, lng, address, priority,
      citizen_name, citizen_phone, departmentId, panchayatId, slaDue
    ]);

    const ticket = insertResult.rows[0];

    // Insert media files if any
    if (media_urls.length > 0) {
      const mediaPromises = media_urls.map(url => 
        db.query(
          'INSERT INTO media (ticket_id, url, type, created_at) VALUES ($1, $2, $3, NOW())',
          [ticket.id, url, url.includes('audio') ? 'AUDIO' : 'IMAGE']
        )
      );
      await Promise.all(mediaPromises);
    }

    // Add to history
    await db.query(`
      INSERT INTO ticket_history (ticket_id, from_status, to_status, comment, created_at)
      VALUES ($1, NULL, 'PENDING', 'Ticket created', NOW())
    `, [ticket.id]);

    // Broadcast real-time update
    const eventData = {
      event: 'ticket.created',
      ticket: {
        id: ticket.id,
        ticket_no: ticket.ticket_no,
        category: ticket.category,
        lat: ticket.lat,
        lng: ticket.lng,
        department_id: ticket.department_id,
        panchayat_id: ticket.panchayat_id,
        priority: ticket.priority,
        status: ticket.status,
        created_at: ticket.created_at
      }
    };

    broadcastTicketUpdate(`dept:${departmentId}`, eventData);
    broadcastTicketUpdate(`panchayat:${panchayatId}`, eventData);

    res.status(201).json({
      message: 'Ticket created successfully',
      ticket: ticket
    });
  } catch (error) {
    console.error('Create ticket error:', error);
    res.status(500).json({ error: 'Failed to create ticket' });
  }
});

// Update ticket status
router.post('/:id/status', authenticateToken, async (req, res) => {
  try {
    const { error } = updateStatusSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }

    const ticketId = req.params.id;
    const { status, comment, assigned_to } = req.body;
    const db = getDb();

    // Get current ticket
    const ticketResult = await db.query('SELECT * FROM tickets WHERE id = $1', [ticketId]);
    
    if (ticketResult.rows.length === 0) {
      return res.status(404).json({ error: 'Ticket not found' });
    }

    const ticket = ticketResult.rows[0];
    const oldStatus = ticket.status;

    // Authorization check
    if (req.user.role === 'DEPT_OFFICER' && ticket.department_id !== req.user.department_id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    // Update ticket
    const updateFields = ['status = $2', 'updated_at = NOW()'];
    const params = [ticketId, status];
    let paramCount = 2;

    if (assigned_to !== undefined) {
      paramCount++;
      updateFields.push(`assigned_to = $${paramCount}`);
      params.push(assigned_to);
    }

    await db.query(`
      UPDATE tickets SET ${updateFields.join(', ')}
      WHERE id = $1
    `, params);

    // Add to history
    await db.query(`
      INSERT INTO ticket_history (ticket_id, from_status, to_status, comment, changed_by, created_at)
      VALUES ($1, $2, $3, $4, $5, NOW())
    `, [ticketId, oldStatus, status, comment || `Status changed to ${status}`, req.user.id]);

    // Broadcast update
    const eventData = {
      event: 'ticket.updated',
      ticket: {
        id: ticket.id,
        ticket_no: ticket.ticket_no,
        status: status,
        old_status: oldStatus,
        updated_by: req.user.name,
        comment: comment
      }
    };

    broadcastTicketUpdate(`dept:${ticket.department_id}`, eventData);
    broadcastTicketUpdate(`panchayat:${ticket.panchayat_id}`, eventData);

    res.json({ message: 'Ticket status updated successfully' });
  } catch (error) {
    console.error('Update ticket status error:', error);
    res.status(500).json({ error: 'Failed to update ticket status' });
  }
});

// Assign ticket
router.post('/:id/assign', authenticateToken, async (req, res) => {
  try {
    const { error } = assignTicketSchema.validate(req.body);
    if (error) {
      return res.status(400).json({ error: error.details[0].message });
    }

    const ticketId = req.params.id;
    const { assigned_to, comment } = req.body;
    const db = getDb();

    // Get ticket and verify user exists
    const [ticketResult, userResult] = await Promise.all([
      db.query('SELECT * FROM tickets WHERE id = $1', [ticketId]),
      db.query('SELECT name FROM users WHERE id = $1 AND active = true', [assigned_to])
    ]);

    if (ticketResult.rows.length === 0) {
      return res.status(404).json({ error: 'Ticket not found' });
    }

    if (userResult.rows.length === 0) {
      return res.status(404).json({ error: 'Assigned user not found' });
    }

    const ticket = ticketResult.rows[0];
    const assignedUser = userResult.rows[0];

    // Authorization check
    if (req.user.role === 'DEPT_OFFICER' && ticket.department_id !== req.user.department_id) {
      return res.status(403).json({ error: 'Access denied' });
    }

    // Update assignment
    await db.query(
      'UPDATE tickets SET assigned_to = $1, updated_at = NOW() WHERE id = $2',
      [assigned_to, ticketId]
    );

    // Add to history
    await db.query(`
      INSERT INTO ticket_history (ticket_id, from_status, to_status, comment, changed_by, created_at)
      VALUES ($1, $2, $2, $3, $4, NOW())
    `, [
      ticketId, 
      ticket.status, 
      comment || `Assigned to ${assignedUser.name}`,
      req.user.id
    ]);

    // Broadcast update
    const eventData = {
      event: 'ticket.assigned',
      ticket: {
        id: ticket.id,
        ticket_no: ticket.ticket_no,
        assigned_to: assigned_to,
        assigned_to_name: assignedUser.name,
        assigned_by: req.user.name
      }
    };

    broadcastTicketUpdate(`dept:${ticket.department_id}`, eventData);
    broadcastTicketUpdate(`user:${assigned_to}`, eventData);

    res.json({ message: 'Ticket assigned successfully' });
  } catch (error) {
    console.error('Assign ticket error:', error);
    res.status(500).json({ error: 'Failed to assign ticket' });
  }
});

module.exports = router;