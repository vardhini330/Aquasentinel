const bcrypt = require('bcryptjs');
const { Pool } = require('pg');

const pool = new Pool({
  connectionString: process.env.DATABASE_URL || 'postgresql://postgres:password@localhost:5432/jharkhand_civic',
});

async function seedDatabase() {
  const client = await pool.connect();
  
  try {
    await client.query('BEGIN');
    console.log('🌱 Starting database seeding...');

    // Clear existing data (in reverse dependency order)
    await client.query('DELETE FROM notifications');
    await client.query('DELETE FROM media');
    await client.query('DELETE FROM ticket_history');
    await client.query('DELETE FROM tickets');
    await client.query('DELETE FROM users');
    await client.query('DELETE FROM panchayats');
    await client.query('DELETE FROM departments');

    // Reset sequences
    await client.query('ALTER SEQUENCE departments_id_seq RESTART WITH 1');
    await client.query('ALTER SEQUENCE users_id_seq RESTART WITH 1');
    await client.query('ALTER SEQUENCE panchayats_id_seq RESTART WITH 1');
    await client.query('ALTER SEQUENCE tickets_id_seq RESTART WITH 1');

    // 1. Seed Departments
    console.log('📊 Seeding departments...');
    const departments = [
      { name: 'Roads & PWD', code: 'ROADS', icon: '🛣', color: '#059669' },
      { name: 'Electricity', code: 'ELECTRICITY', icon: '💡', color: '#DC2626' },
      { name: 'Sanitation', code: 'SANITATION', icon: '🗑', color: '#16A34A' },
      { name: 'Water Supply', code: 'WATER', icon: '💧', color: '#2563EB' },
      { name: 'Parks & Greenery', code: 'PARKS', icon: '🌳', color: '#65A30D' },
      { name: 'General Administration', code: 'GENERAL', icon: '🏛', color: '#7C3AED' }
    ];

    for (const dept of departments) {
      await client.query(
        'INSERT INTO departments (name, code, icon, color) VALUES ($1, $2, $3, $4)',
        [dept.name, dept.code, dept.icon, dept.color]
      );
    }

    // 2. Seed Users
    console.log('👥 Seeding users...');
    const passwordHash = await bcrypt.hash('password123', 10);
    const users = [
      {
        name: 'Super Administrator',
        email: 'admin@jharkhand.gov.in',
        phone: '+91-9876543210',
        role: 'SUPER_ADMIN',
        department_id: null
      },
      {
        name: 'Sanitation Department Officer',
        email: 'sanitation@jharkhand.gov.in',
        phone: '+91-9876543211',
        role: 'DEPT_OFFICER',
        department_id: 3 // Sanitation
      },
      {
        name: 'Roads Department Officer',
        email: 'roads@jharkhand.gov.in',
        phone: '+91-9876543212',
        role: 'DEPT_OFFICER',
        department_id: 1 // Roads
      },
      {
        name: 'Rajesh Kumar (Field Officer)',
        email: 'rajesh.field@jharkhand.gov.in',
        phone: '+91-9876543213',
        role: 'FIELD_OFFICER',
        department_id: 3 // Sanitation
      },
      {
        name: 'Priya Singh (Field Officer)',
        email: 'priya.field@jharkhand.gov.in',
        phone: '+91-9876543214',
        role: 'FIELD_OFFICER',
        department_id: 1 // Roads
      }
    ];

    for (const user of users) {
      await client.query(
        'INSERT INTO users (name, email, phone, password_hash, role, department_id) VALUES ($1, $2, $3, $4, $5, $6)',
        [user.name, user.email, user.phone, passwordHash, user.role, user.department_id]
      );
    }

    // 3. Seed Panchayats (Sample Jharkhand panchayats)
    console.log('🏘 Seeding panchayats...');
    const panchayats = [
      { name: 'Ranchi Nagar Nigam', district: 'Ranchi', lat: 23.3441, lng: 85.3096, population: 1073440 },
      { name: 'Jamshedpur Nagar Nigam', district: 'East Singhbhum', lat: 22.8046, lng: 86.2029, population: 631216 },
      { name: 'Dhanbad Municipal Corporation', district: 'Dhanbad', lat: 23.7957, lng: 86.4304, population: 267362 },
      { name: 'Bokaro Steel City', district: 'Bokaro', lat: 23.6693, lng: 86.1511, population: 511645 },
      { name: 'Deoghar Municipality', district: 'Deoghar', lat: 24.4844, lng: 86.6956, population: 103658 },
      { name: 'Hazaribagh Nagar Parishad', district: 'Hazaribagh', lat: 23.9981, lng: 85.3644, population: 153599 },
      { name: 'Giridih Nagar Parishad', district: 'Giridih', lat: 24.1899, lng: 86.3094, population: 108037 },
      { name: 'Ramgarh Cantonment', district: 'Ramgarh', lat: 23.6307, lng: 85.5181, population: 73006 },
      { name: 'Chaibasa Municipality', district: 'West Singhbhum', lat: 22.5562, lng: 85.8089, population: 57295 },
      { name: 'Dumka Municipality', district: 'Dumka', lat: 24.2676, lng: 87.2497, population: 48000 },
      { name: 'Godda Nagar Panchayat', district: 'Godda', lat: 24.8270, lng: 87.2142, population: 35000 },
      { name: 'Pakur Nagar Panchayat', district: 'Pakur', lat: 24.6340, lng: 87.8494, population: 28000 },
      { name: 'Sahibganj Municipality', district: 'Sahibganj', lat: 25.2452, lng: 87.6464, population: 32000 },
      { name: 'Palamu Municipality', district: 'Palamu', lat: 24.0156, lng: 84.1336, population: 45000 },
      { name: 'Garhwa Nagar Panchayat', district: 'Garhwa', lat: 24.1542, lng: 83.8067, population: 38000 }
    ];

    for (const panchayat of panchayats) {
      await client.query(
        'INSERT INTO panchayats (name, district, lat, lng, population) VALUES ($1, $2, $3, $4, $5)',
        [panchayat.name, panchayat.district, panchayat.lat, panchayat.lng, panchayat.population]
      );
    }

    // 4. Seed Sample Tickets
    console.log('🎫 Seeding sample tickets...');
    const sampleTickets = [
      {
        category: 'ROADS',
        description: 'Large pothole on Main Road causing traffic issues and vehicle damage. Urgent repair needed.',
        lat: 23.3441,
        lng: 85.3096,
        address: 'Main Road, Near City Center, Ranchi',
        priority: 'HIGH',
        status: 'PENDING',
        department_id: 1,
        panchayat_id: 1,
        citizen_name: 'Ramesh Kumar',
        citizen_phone: '+91-9876543220'
      },
      {
        category: 'ELECTRICITY',
        description: 'Street lights not working in residential area for past 3 days. Safety concern for residents.',
        lat: 22.8046,
        lng: 86.2029,
        address: 'Shastri Nagar, Jamshedpur',
        priority: 'MEDIUM',
        status: 'ACKNOWLEDGED',
        department_id: 2,
        panchayat_id: 2,
        citizen_name: 'Sunita Devi',
        citizen_phone: '+91-9876543221',
        assigned_to: 5
      },
      {
        category: 'SANITATION',
        description: 'Garbage collection not done for 5 days. Foul smell and health hazard in the area.',
        lat: 23.7957,
        lng: 86.4304,
        address: 'Housing Colony, Dhanbad',
        priority: 'HIGH',
        status: 'IN_PROGRESS',
        department_id: 3,
        panchayat_id: 3,
        citizen_name: 'Amit Singh',
        citizen_phone: '+91-9876543222',
        assigned_to: 4
      },
      {
        category: 'WATER',
        description: 'Water supply pipeline burst. No water supply in the area since morning.',
        lat: 23.6693,
        lng: 86.1511,
        address: 'Sector 4, Bokaro Steel City',
        priority: 'CRITICAL',
        status: 'RESOLVED',
        department_id: 4,
        panchayat_id: 4,
        citizen_name: 'Pooja Gupta'
      },
      {
        category: 'PARKS',
        description: 'Public park needs maintenance. Broken benches and overgrown grass.',
        lat: 24.4844,
        lng: 86.6956,
        address: 'Central Park, Deoghar',
        priority: 'LOW',
        status: 'PENDING',
        department_id: 5,
        panchayat_id: 5,
        citizen_name: 'Ravi Sharma',
        citizen_phone: '+91-9876543223'
      }
    ];

    for (let i = 0; i < sampleTickets.length; i++) {
      const ticket = sampleTickets[i];
      const ticketNo = `JH${Date.now() + i}`.slice(-12);
      
      // Calculate SLA due date based on priority
      const slaDue = new Date();
      switch (ticket.priority) {
        case 'CRITICAL': slaDue.setHours(slaDue.getHours() + 4); break;
        case 'HIGH': slaDue.setHours(slaDue.getHours() + 12); break;
        case 'MEDIUM': slaDue.setHours(slaDue.getHours() + 24); break;
        default: slaDue.setHours(slaDue.getHours() + 72); break;
      }

      const result = await client.query(`
        INSERT INTO tickets (
          ticket_no, category, description, lat, lng, address, priority, status,
          department_id, panchayat_id, citizen_name, citizen_phone, assigned_to, sla_due
        ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14)
        RETURNING id
      `, [
        ticketNo, ticket.category, ticket.description, ticket.lat, ticket.lng,
        ticket.address, ticket.priority, ticket.status, ticket.department_id,
        ticket.panchayat_id, ticket.citizen_name, ticket.citizen_phone,
        ticket.assigned_to || null, slaDue
      ]);

      const ticketId = result.rows[0].id;

      // Add initial history entry
      await client.query(`
        INSERT INTO ticket_history (ticket_id, from_status, to_status, comment, created_at)
        VALUES ($1, NULL, $2, 'Ticket created', NOW() - INTERVAL '${Math.floor(Math.random() * 24)} hours')
      `, [ticketId, ticket.status]);

      // Add additional history for non-pending tickets
      if (ticket.status !== 'PENDING') {
        await client.query(`
          INSERT INTO ticket_history (ticket_id, from_status, to_status, comment, changed_by, created_at)
          VALUES ($1, 'PENDING', 'ACKNOWLEDGED', 'Ticket acknowledged by department', 2, NOW() - INTERVAL '${Math.floor(Math.random() * 12)} hours')
        `, [ticketId]);

        if (ticket.status === 'IN_PROGRESS' || ticket.status === 'RESOLVED') {
          await client.query(`
            INSERT INTO ticket_history (ticket_id, from_status, to_status, comment, changed_by, created_at)
            VALUES ($1, 'ACKNOWLEDGED', 'IN_PROGRESS', 'Work started by field officer', $2, NOW() - INTERVAL '${Math.floor(Math.random() * 6)} hours')
          `, [ticketId, ticket.assigned_to || 4]);
        }

        if (ticket.status === 'RESOLVED') {
          await client.query(`
            INSERT INTO ticket_history (ticket_id, from_status, to_status, comment, changed_by, created_at)
            VALUES ($1, 'IN_PROGRESS', 'RESOLVED', 'Issue resolved successfully', $2, NOW() - INTERVAL '${Math.floor(Math.random() * 2)} hours')
          `, [ticketId, ticket.assigned_to || 4]);
        }
      }
    }

    // 5. Seed Sample Notifications
    console.log('🔔 Seeding sample notifications...');
    const notifications = [
      {
        recipient_id: 2, // Sanitation officer
        title: 'New High Priority Ticket',
        message: 'A new high priority sanitation issue has been reported in Dhanbad.',
        type: 'WARNING'
      },
      {
        recipient_id: 4, // Field officer
        title: 'Ticket Assigned',
        message: 'Ticket JH001 has been assigned to you for resolution.',
        type: 'INFO'
      },
      {
        recipient_id: 1, // Super admin
        title: 'System Alert',
        message: 'Multiple critical tickets pending resolution. Immediate attention required.',
        type: 'ERROR'
      }
    ];

    for (const notif of notifications) {
      await client.query(
        'INSERT INTO notifications (recipient_id, title, message, type) VALUES ($1, $2, $3, $4)',
        [notif.recipient_id, notif.title, notif.message, notif.type]
      );
    }

    await client.query('COMMIT');
    console.log('✅ Database seeding completed successfully!');
    console.log('\n🔑 Login Credentials:');
    console.log('Super Admin: admin@jharkhand.gov.in / password123');
    console.log('Dept Officer: sanitation@jharkhand.gov.in / password123');
    console.log('Field Officer: rajesh.field@jharkhand.gov.in / password123');

  } catch (error) {
    await client.query('ROLLBACK');
    console.error('❌ Database seeding failed:', error);
    throw error;
  } finally {
    client.release();
  }
}

// Run seeding if called directly
if (require.main === module) {
  seedDatabase()
    .then(() => {
      console.log('🎉 Seeding process completed!');
      process.exit(0);
    })
    .catch((error) => {
      console.error('💥 Seeding process failed:', error);
      process.exit(1);
    });
}

module.exports = { seedDatabase };