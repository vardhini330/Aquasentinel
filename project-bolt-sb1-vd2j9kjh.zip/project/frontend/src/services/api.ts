import axios from 'axios';

// Create axios instance
export const api = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000/api',
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add auth token
api.interceptors.request.use(
  (config) => {
    // Token will be set by auth store
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor to handle errors
api.interceptors.response.use(
  (response) => {
    return response;
  },
  async (error) => {
    const originalRequest = error.config;

    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;

      // Try to refresh token
      try {
        const { useAuthStore } = await import('../stores/authStore');
        await useAuthStore.getState().refreshAuth();
        
        // Retry original request
        return api(originalRequest);
      } catch (refreshError) {
        // Refresh failed, redirect to login
        const { useAuthStore } = await import('../stores/authStore');
        useAuthStore.getState().logout();
        return Promise.reject(refreshError);
      }
    }

    return Promise.reject(error);
  }
);

// API service functions
export const authService = {
  login: (email: string, password: string, rememberMe?: boolean) =>
    api.post('/auth/login', { email, password, rememberMe }),
  
  refresh: (refreshToken: string) =>
    api.post('/auth/refresh', { refreshToken }),
  
  getProfile: () =>
    api.get('/auth/me'),
  
  logout: () =>
    api.post('/auth/logout')
};

export const departmentService = {
  getAll: () =>
    api.get('/departments'),
  
  getById: (id: number) =>
    api.get(`/departments/${id}`),
  
  getStats: (id: number) =>
    api.get(`/departments/${id}/stats`)
};

export const panchayatService = {
  getAll: (params?: any) =>
    api.get('/panchayats', { params }),
  
  getById: (id: number) =>
    api.get(`/panchayats/${id}`),
  
  getStats: (id: number, departmentId?: number) =>
    api.get(`/panchayats/${id}/stats`, { 
      params: departmentId ? { departmentId } : {} 
    })
};

export const ticketService = {
  getAll: (params?: any) =>
    api.get('/tickets', { params }),
  
  getById: (id: number) =>
    api.get(`/tickets/${id}`),
  
  create: (data: any) =>
    api.post('/tickets/public', data),
  
  updateStatus: (id: number, data: any) =>
    api.post(`/tickets/${id}/status`, data),
  
  assign: (id: number, data: any) =>
    api.post(`/tickets/${id}/assign`, data)
};

export const analyticsService = {
  getDepartment: (id: number, params?: any) =>
    api.get(`/analytics/department/${id}`, { params }),
  
  getPanchayat: (id: number, params?: any) =>
    api.get(`/analytics/panchayat/${id}`, { params }),
  
  export: (type: 'department' | 'panchayat', id: number, params?: any) =>
    api.get(`/analytics/export/${type}/${id}`, { 
      params,
      responseType: 'blob'
    })
};

export const notificationService = {
  getAll: (params?: any) =>
    api.get('/notifications', { params }),
  
  markAsRead: (id: number) =>
    api.patch(`/notifications/${id}/read`),
  
  markAllAsRead: () =>
    api.patch('/notifications/read-all'),
  
  getCounts: () =>
    api.get('/notifications/counts'),
  
  sendTest: (data: any) =>
    api.post('/notifications/test', data)
};

export const mediaService = {
  upload: (ticketId: number, files: FormData) =>
    api.post(`/media/upload/${ticketId}`, files, {
      headers: {
        'Content-Type': 'multipart/form-data'
      }
    }),
  
  getTicketMedia: (ticketId: number) =>
    api.get(`/media/ticket/${ticketId}`),
  
  delete: (id: number) =>
    api.delete(`/media/${id}`)
};