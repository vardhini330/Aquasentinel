const redis = require('redis');

let client;
let publisher;
let subscriber;

const initRedis = async () => {
  const redisUrl = process.env.REDIS_URL || 'redis://localhost:6379';
  
  client = redis.createClient({ url: redisUrl });
  publisher = redis.createClient({ url: redisUrl });
  subscriber = redis.createClient({ url: redisUrl });

  await client.connect();
  await publisher.connect();
  await subscriber.connect();

  console.log('✅ Redis connected successfully');
};

const getRedisClient = () => client;
const getRedisPublisher = () => publisher;
const getRedisSubscriber = () => subscriber;

module.exports = { 
  initRedis, 
  getRedisClient, 
  getRedisPublisher, 
  getRedisSubscriber 
};