const express = require('express');
const { getDb } = require('../config/database');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

// Get all departments
router.get('/', authenticateToken, async (req, res) => {
  try {
    const db = getDb();
    const result = await db.query(`
      SELECT d.*, 
             COUNT(t.id) as total_tickets,
             COUNT(CASE WHEN t.status = 'PENDING' THEN 1 END) as pending_tickets,
             COUNT(CASE WHEN t.status = 'IN_PROGRESS' THEN 1 END) as in_progress_tickets,
             COUNT(CASE WHEN t.status = 'RESOLVED' THEN 1 END) as resolved_tickets
      FROM departments d
      LEFT JOIN tickets t ON d.id = t.department_id AND t.created_at >= NOW() - INTERVAL '30 days'
      GROUP BY d.id
      ORDER BY d.name
    `);

    res.json(result.rows);
  } catch (error) {
    console.error('Get departments error:', error);
    res.status(500).json({ error: 'Failed to fetch departments' });
  }
});

// Get department by ID
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const db = getDb();
    const result = await db.query(
      'SELECT * FROM departments WHERE id = $1',
      [req.params.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Department not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Get department error:', error);
    res.status(500).json({ error: 'Failed to fetch department' });
  }
});

// Get department statistics
router.get('/:id/stats', authenticateToken, async (req, res) => {
  try {
    const departmentId = req.params.id;
    const db = getDb();

    // Basic counts
    const countsResult = await db.query(`
      SELECT 
        COUNT(*) as total_tickets,
        COUNT(CASE WHEN status = 'PENDING' THEN 1 END) as pending,
        COUNT(CASE WHEN status = 'IN_PROGRESS' THEN 1 END) as in_progress,
        COUNT(CASE WHEN status = 'RESOLVED' THEN 1 END) as resolved,
        COUNT(CASE WHEN status = 'PENDING' AND sla_due < NOW() THEN 1 END) as overdue
      FROM tickets 
      WHERE department_id = $1 AND created_at >= NOW() - INTERVAL '30 days'
    `, [departmentId]);

    // Average resolution time
    const avgResolutionResult = await db.query(`
      SELECT AVG(EXTRACT(EPOCH FROM (updated_at - created_at))/3600) as avg_hours
      FROM tickets 
      WHERE department_id = $1 AND status = 'RESOLVED' 
      AND updated_at >= NOW() - INTERVAL '30 days'
    `, [departmentId]);

    // Daily trend (last 7 days)
    const trendResult = await db.query(`
      SELECT 
        DATE(created_at) as date,
        COUNT(*) as count
      FROM tickets 
      WHERE department_id = $1 AND created_at >= NOW() - INTERVAL '7 days'
      GROUP BY DATE(created_at)
      ORDER BY date
    `, [departmentId]);

    // Top panchayats by ticket count
    const panchayatsResult = await db.query(`
      SELECT 
        p.id, p.name, p.district,
        COUNT(t.id) as ticket_count
      FROM panchayats p
      LEFT JOIN tickets t ON p.id = t.panchayat_id AND t.department_id = $1
      WHERE t.created_at >= NOW() - INTERVAL '30 days' OR t.id IS NULL
      GROUP BY p.id, p.name, p.district
      ORDER BY ticket_count DESC
      LIMIT 5
    `, [departmentId]);

    res.json({
      counts: countsResult.rows[0],
      avgResolutionHours: parseFloat(avgResolutionResult.rows[0]?.avg_hours) || 0,
      dailyTrend: trendResult.rows,
      topPanchayats: panchayatsResult.rows
    });
  } catch (error) {
    console.error('Get department stats error:', error);
    res.status(500).json({ error: 'Failed to fetch department statistics' });
  }
});

module.exports = router;