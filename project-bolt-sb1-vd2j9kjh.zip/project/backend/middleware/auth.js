const jwt = require('jsonwebtoken');
const { getDb } = require('../config/database');

const authenticateToken = async (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access token required' });
  }

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    
    // Get fresh user data
    const db = getDb();
    const result = await db.query(
      'SELECT id, name, email, role, department_id, active FROM users WHERE id = $1',
      [decoded.userId]
    );

    if (result.rows.length === 0 || !result.rows[0].active) {
      return res.status(401).json({ error: 'Invalid or inactive user' });
    }

    req.user = result.rows[0];
    next();
  } catch (error) {
    console.error('Auth error:', error);
    return res.status(403).json({ error: 'Invalid or expired token' });
  }
};

const authorizeRoles = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Insufficient permissions' });
    }
    next();
  };
};

const authorizeDepartment = (req, res, next) => {
  const departmentId = req.params.departmentId || req.query.departmentId || req.body.department_id;
  
  // Super admins can access all departments
  if (req.user.role === 'SUPER_ADMIN') {
    return next();
  }

  // Department officers can only access their department
  if (req.user.role === 'DEPT_OFFICER' && req.user.department_id !== parseInt(departmentId)) {
    return res.status(403).json({ error: 'Access denied to this department' });
  }

  next();
};

module.exports = { authenticateToken, authorizeRoles, authorizeDepartment };