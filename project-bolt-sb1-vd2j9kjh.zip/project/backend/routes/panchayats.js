const express = require('express');
const { getDb } = require('../config/database');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

// Get all panchayats with optional filtering
router.get('/', authenticateToken, async (req, res) => {
  try {
    const { departmentId, district, search, page = 1, limit = 50 } = req.query;
    const offset = (page - 1) * limit;
    
    let query = `
      SELECT p.*,
             COUNT(t.id) as total_tickets,
             COUNT(CASE WHEN t.status = 'PENDING' THEN 1 END) as pending_tickets,
             COUNT(CASE WHEN t.status = 'IN_PROGRESS' THEN 1 END) as in_progress_tickets,
             COUNT(CASE WHEN t.status = 'RESOLVED' THEN 1 END) as resolved_tickets
      FROM panchayats p
      LEFT JOIN tickets t ON p.id = t.panchayat_id 
    `;

    const conditions = [];
    const params = [];
    let paramCount = 0;

    if (departmentId) {
      paramCount++;
      conditions.push(`t.department_id = $${paramCount}`);
      params.push(departmentId);
    }

    if (district) {
      paramCount++;
      conditions.push(`p.district ILIKE $${paramCount}`);
      params.push(`%${district}%`);
    }

    if (search) {
      paramCount++;
      conditions.push(`p.name ILIKE $${paramCount}`);
      params.push(`%${search}%`);
    }

    if (conditions.length > 0) {
      query += ` WHERE ${conditions.join(' AND ')}`;
    }

    query += `
      GROUP BY p.id
      ORDER BY p.name
      LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}
    `;

    params.push(limit, offset);

    const db = getDb();
    const result = await db.query(query, params);

    // Get total count
    let countQuery = 'SELECT COUNT(DISTINCT p.id) as total FROM panchayats p';
    let countParams = [];
    let countParamCount = 0;

    if (district || search) {
      countQuery += ' WHERE ';
      const countConditions = [];
      
      if (district) {
        countParamCount++;
        countConditions.push(`p.district ILIKE $${countParamCount}`);
        countParams.push(`%${district}%`);
      }

      if (search) {
        countParamCount++;
        countConditions.push(`p.name ILIKE $${countParamCount}`);
        countParams.push(`%${search}%`);
      }

      countQuery += countConditions.join(' AND ');
    }

    const countResult = await db.query(countQuery, countParams);
    const total = parseInt(countResult.rows[0].total);

    res.json({
      panchayats: result.rows,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Get panchayats error:', error);
    res.status(500).json({ error: 'Failed to fetch panchayats' });
  }
});

// Get panchayat by ID
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const db = getDb();
    const result = await db.query(
      'SELECT * FROM panchayats WHERE id = $1',
      [req.params.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Panchayat not found' });
    }

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Get panchayat error:', error);
    res.status(500).json({ error: 'Failed to fetch panchayat' });
  }
});

// Get panchayat statistics
router.get('/:id/stats', authenticateToken, async (req, res) => {
  try {
    const panchayatId = req.params.id;
    const { departmentId } = req.query;
    const db = getDb();

    let whereClause = 'WHERE panchayat_id = $1';
    let params = [panchayatId];

    if (departmentId) {
      whereClause += ' AND department_id = $2';
      params.push(departmentId);
    }

    // Basic counts
    const countsResult = await db.query(`
      SELECT 
        COUNT(*) as total_tickets,
        COUNT(CASE WHEN status = 'PENDING' THEN 1 END) as pending,
        COUNT(CASE WHEN status = 'IN_PROGRESS' THEN 1 END) as in_progress,
        COUNT(CASE WHEN status = 'RESOLVED' THEN 1 END) as resolved,
        COUNT(CASE WHEN status = 'PENDING' AND sla_due < NOW() THEN 1 END) as overdue
      FROM tickets 
      ${whereClause} AND created_at >= NOW() - INTERVAL '30 days'
    `, params);

    // Average resolution time
    const avgResolutionResult = await db.query(`
      SELECT AVG(EXTRACT(EPOCH FROM (updated_at - created_at))/3600) as avg_hours
      FROM tickets 
      ${whereClause} AND status = 'RESOLVED' 
      AND updated_at >= NOW() - INTERVAL '30 days'
    `, params);

    // Daily trend (last 7 days)
    const trendResult = await db.query(`
      SELECT 
        DATE(created_at) as date,
        COUNT(*) as count
      FROM tickets 
      ${whereClause} AND created_at >= NOW() - INTERVAL '7 days'
      GROUP BY DATE(created_at)
      ORDER BY date
    `, params);

    // Category breakdown
    const categoryResult = await db.query(`
      SELECT 
        category,
        COUNT(*) as count
      FROM tickets 
      ${whereClause} AND created_at >= NOW() - INTERVAL '30 days'
      GROUP BY category
      ORDER BY count DESC
    `, params);

    res.json({
      counts: countsResult.rows[0],
      avgResolutionHours: parseFloat(avgResolutionResult.rows[0]?.avg_hours) || 0,
      dailyTrend: trendResult.rows,
      categoryBreakdown: categoryResult.rows
    });
  } catch (error) {
    console.error('Get panchayat stats error:', error);
    res.status(500).json({ error: 'Failed to fetch panchayat statistics' });
  }
});

module.exports = router;