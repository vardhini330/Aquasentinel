const express = require('express');
const { getDb } = require('../config/database');
const { authenticateToken } = require('../middleware/auth');
const { broadcastNotification } = require('../websocket/handler');

const router = express.Router();

// Get user notifications
router.get('/', authenticateToken, async (req, res) => {
  try {
    const { page = 1, limit = 20, unread = false } = req.query;
    const offset = (page - 1) * limit;
    const db = getDb();

    let whereClause = 'WHERE recipient_id = $1';
    const params = [req.user.id];

    if (unread === 'true') {
      whereClause += ' AND read_at IS NULL';
    }

    const result = await db.query(`
      SELECT * FROM notifications 
      ${whereClause}
      ORDER BY created_at DESC
      LIMIT $${params.length + 1} OFFSET $${params.length + 2}
    `, [...params, limit, offset]);

    // Get total count
    const countResult = await db.query(`
      SELECT COUNT(*) as total FROM notifications ${whereClause}
    `, params);

    const total = parseInt(countResult.rows[0].total);

    res.json({
      notifications: result.rows,
      pagination: {
        page: parseInt(page),
        limit: parseInt(limit),
        total,
        pages: Math.ceil(total / limit)
      }
    });
  } catch (error) {
    console.error('Get notifications error:', error);
    res.status(500).json({ error: 'Failed to fetch notifications' });
  }
});

// Mark notification as read
router.patch('/:id/read', authenticateToken, async (req, res) => {
  try {
    const db = getDb();
    const result = await db.query(
      'UPDATE notifications SET read_at = NOW() WHERE id = $1 AND recipient_id = $2 RETURNING *',
      [req.params.id, req.user.id]
    );

    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'Notification not found' });
    }

    res.json({ message: 'Notification marked as read' });
  } catch (error) {
    console.error('Mark notification read error:', error);
    res.status(500).json({ error: 'Failed to mark notification as read' });
  }
});

// Mark all notifications as read
router.patch('/read-all', authenticateToken, async (req, res) => {
  try {
    const db = getDb();
    await db.query(
      'UPDATE notifications SET read_at = NOW() WHERE recipient_id = $1 AND read_at IS NULL',
      [req.user.id]
    );

    res.json({ message: 'All notifications marked as read' });
  } catch (error) {
    console.error('Mark all notifications read error:', error);
    res.status(500).json({ error: 'Failed to mark all notifications as read' });
  }
});

// Test notification endpoint (for development)
router.post('/test', authenticateToken, async (req, res) => {
  try {
    const { message, type = 'INFO' } = req.body;
    
    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }

    const db = getDb();
    const result = await db.query(`
      INSERT INTO notifications (recipient_id, title, message, type, channel, created_at)
      VALUES ($1, $2, $3, $4, 'WEB', NOW())
      RETURNING *
    `, [req.user.id, 'Test Notification', message, type]);

    const notification = result.rows[0];

    // Broadcast real-time notification
    broadcastNotification(req.user.id, {
      event: 'notification.new',
      notification: notification
    });

    res.json({
      message: 'Test notification sent successfully',
      notification: notification
    });
  } catch (error) {
    console.error('Send test notification error:', error);
    res.status(500).json({ error: 'Failed to send test notification' });
  }
});

// Get notification counts
router.get('/counts', authenticateToken, async (req, res) => {
  try {
    const db = getDb();
    const result = await db.query(`
      SELECT 
        COUNT(*) as total,
        COUNT(CASE WHEN read_at IS NULL THEN 1 END) as unread
      FROM notifications 
      WHERE recipient_id = $1
    `, [req.user.id]);

    res.json(result.rows[0]);
  } catch (error) {
    console.error('Get notification counts error:', error);
    res.status(500).json({ error: 'Failed to fetch notification counts' });
  }
});

module.exports = router;