import { create } from 'zustand';
import { persist } from 'zustand/middleware';

type Language = 'en' | 'hi';

interface TranslationState {
  language: Language;
  setLanguage: (lang: Language) => void;
}

// Translation store
const useTranslationStore = create<TranslationState>()(
  persist(
    (set) => ({
      language: 'en',
      setLanguage: (lang: Language) => {
        set({ language: lang });
        // Update document lang attribute for screen readers
        document.documentElement.lang = lang;
        // Update document class for font styling
        if (lang === 'hi') {
          document.documentElement.classList.add('lang-hi');
        } else {
          document.documentElement.classList.remove('lang-hi');
        }
      }
    }),
    {
      name: 'translation-storage'
    }
  )
);

// Translation data
const translations = {
  en: {
    // Header
    'header.title': 'Jharkhand Civic Issue Management System',
    'header.subtitle': 'Government of Jharkhand',

    // Navigation
    'nav.home': 'Home',
    'nav.about': 'About Us',
    'nav.dashboard': 'Dashboard',
    'nav.notifications': 'Notifications',
    
    // Common
    'common.loading': 'Loading...',
    'common.error': 'Error',
    'common.success': 'Success',
    'common.cancel': 'Cancel',
    'common.save': 'Save',
    'common.delete': 'Delete',
    'common.edit': 'Edit',
    'common.view': 'View',
    'common.close': 'Close',
    'common.logout': 'Logout',
    'common.login': 'Login',
    'common.search': 'Search',
    'common.filter': 'Filter',
    'common.export': 'Export',
    'common.refresh': 'Refresh',
    'common.submit': 'Submit',

    // Login
    'login.title': 'Sign in to your account',
    'login.email': 'Email address',
    'login.password': 'Password',
    'login.rememberMe': 'Remember me',
    'login.forgotPassword': 'Forgot your password?',
    'login.signIn': 'Sign in',

    // Dashboard
    'dashboard.welcome': 'Welcome to the Administrative Portal',
    'dashboard.selectDepartment': 'Select a department to manage civic issues',
    'dashboard.cmTitle': 'Hon\'ble Chief Minister - Jharkhand',

    // Departments
    'dept.roads': 'Roads & PWD',
    'dept.electricity': 'Electricity',
    'dept.sanitation': 'Sanitation',
    'dept.water': 'Water Supply',
    'dept.parks': 'Parks & Greenery',
    'dept.general': 'General Administration',

    // Statistics
    'stats.totalTickets': 'Total Issues',
    'stats.pending': 'Pending',
    'stats.inProgress': 'In Progress',
    'stats.resolved': 'Resolved',
    'stats.overdue': 'Overdue',

    // Tickets
    'ticket.id': 'Ticket ID',
    'ticket.title': 'Title',
    'ticket.status': 'Status',
    'ticket.priority': 'Priority',
    'ticket.location': 'Location',
    'ticket.assignedTo': 'Assigned To',
    'ticket.dateReported': 'Date Reported',
    'ticket.description': 'Description',

    // Status
    'status.pending': 'Pending',
    'status.acknowledged': 'Acknowledged',
    'status.inProgress': 'In Progress',
    'status.resolved': 'Resolved',
    'status.verified': 'Verified',
    'status.closed': 'Closed',

    // Priority
    'priority.low': 'Low',
    'priority.medium': 'Medium',
    'priority.high': 'High',
    'priority.critical': 'Critical',

    // About
    'about.title': 'About the Portal',
    'about.description': 'This portal enables efficient management of civic issues reported by citizens of Jharkhand. Government officers can track, assign, and resolve issues in a systematic manner.',
    'about.howItWorks': 'How it works',
    'about.contact': 'Contact & Help',
    'about.importantLinks': 'Important Links',
  },

  hi: {
    // Header
    'header.title': 'झारखंड नागरिक समस्या प्रबंधन प्रणाली',
    'header.subtitle': 'झारखंड सरकार',

    // Navigation  
    'nav.home': 'होम',
    'nav.about': 'हमारे बारे में',
    'nav.dashboard': 'डैशबोर्ड',
    'nav.notifications': 'सूचनाएं',

    // Common
    'common.loading': 'लोड हो रहा है...',
    'common.error': 'त्रुटि',
    'common.success': 'सफलता',
    'common.cancel': 'रद्द करें',
    'common.save': 'सहेजें',
    'common.delete': 'हटाएं',
    'common.edit': 'संपादित करें',
    'common.view': 'देखें',
    'common.close': 'बंद करें',
    'common.logout': 'लॉग आउट',
    'common.login': 'लॉग इन',
    'common.search': 'खोजें',
    'common.filter': 'फिल्टर',
    'common.export': 'निर्यात',
    'common.refresh': 'ताज़ा करें',
    'common.submit': 'जमा करें',

    // Login
    'login.title': 'अपने खाते में साइन इन करें',
    'login.email': 'ईमेल पता',
    'login.password': 'पासवर्ड',
    'login.rememberMe': 'मुझे याद रखें',
    'login.forgotPassword': 'अपना पासवर्ड भूल गए?',
    'login.signIn': 'साइन इन करें',

    // Dashboard
    'dashboard.welcome': 'प्रशासनिक पोर्टल में आपका स्वागत है',
    'dashboard.selectDepartment': 'नागरिक समस्याओं के प्रबंधन के लिए एक विभाग का चयन करें',
    'dashboard.cmTitle': 'माननीय मुख्यमंत्री - झारखंड',

    // Departments
    'dept.roads': 'सड़कें और लोक निर्माण',
    'dept.electricity': 'विद्युत',
    'dept.sanitation': 'स्वच्छता',
    'dept.water': 'जल आपूर्ति',
    'dept.parks': 'उद्यान और हरियाली',
    'dept.general': 'सामान्य प्रशासन',

    // Statistics
    'stats.totalTickets': 'कुल समस्याएं',
    'stats.pending': 'लंबित',
    'stats.inProgress': 'प्रगति में',
    'stats.resolved': 'हल',
    'stats.overdue': 'विलंबित',

    // Tickets
    'ticket.id': 'टिकट आईडी',
    'ticket.title': 'शीर्षक',
    'ticket.status': 'स्थिति',
    'ticket.priority': 'प्राथमिकता',
    'ticket.location': 'स्थान',
    'ticket.assignedTo': 'को सौंपा गया',
    'ticket.dateReported': 'रिपोर्ट की तारीख',
    'ticket.description': 'विवरण',

    // Status
    'status.pending': 'लंबित',
    'status.acknowledged': 'स्वीकृत',
    'status.inProgress': 'प्रगति में',
    'status.resolved': 'हल',
    'status.verified': 'सत्यापित',
    'status.closed': 'बंद',

    // Priority
    'priority.low': 'कम',
    'priority.medium': 'मध्यम',
    'priority.high': 'उच्च',
    'priority.critical': 'गंभीर',

    // About
    'about.title': 'पोर्टल के बारे में',
    'about.description': 'यह पोर्टल झारखंड के नागरिकों द्वारा रिपोर्ट की गई नागरिक समस्याओं का कुशल प्रबंधन सक्षम बनाता है। सरकारी अधिकारी व्यवस्थित तरीके से समस्याओं को ट्रैक, असाइन और हल कर सकते हैं।',
    'about.howItWorks': 'यह कैसे काम करता है',
    'about.contact': 'संपर्क और सहायता',
    'about.importantLinks': 'महत्वपूर्ण लिंक',
  }
};

// Hook for using translations
export const useTranslation = () => {
  const { language, setLanguage } = useTranslationStore();

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations['en']] || key;
  };

  return {
    language,
    setLanguage,
    t
  };
};