/*
  # Initial Database Schema for Jharkhand Civic Issue Management System

  1. New Tables
    - `departments` - Government departments (Roads, Electricity, Sanitation, etc.)
    - `users` - System users (Super Admin, Department Officers, Field Officers)
    - `panchayats` - Panchayat/ward information with location data
    - `tickets` - Civic issue reports with full lifecycle tracking
    - `ticket_history` - Audit trail for all ticket status changes
    - `media` - File attachments (photos, audio) for tickets
    - `notifications` - User notifications system

  2. Security
    - Enable RLS on all tables
    - Add policies for role-based access control
    - Password hashing for user authentication

  3. Features
    - Full audit trail for ticket lifecycle
    - Geospatial support for location-based queries
    - SLA tracking with due dates
    - Multi-media support for evidence
    - Real-time notification system
*/

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Departments table
CREATE TABLE IF NOT EXISTS departments (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  code VARCHAR(20) NOT NULL UNIQUE,
  description TEXT,
  icon VARCHAR(50),
  color VARCHAR(7) DEFAULT '#059669',
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Users table
CREATE TABLE IF NOT EXISTS users (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  phone VARCHAR(15),
  password_hash VARCHAR(255) NOT NULL,
  role VARCHAR(20) NOT NULL CHECK (role IN ('SUPER_ADMIN', 'DEPT_OFFICER', 'FIELD_OFFICER')),
  department_id INTEGER REFERENCES departments(id),
  active BOOLEAN DEFAULT true,
  last_login TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Panchayats table
CREATE TABLE IF NOT EXISTS panchayats (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  district VARCHAR(50) NOT NULL,
  state VARCHAR(50) DEFAULT 'Jharkhand',
  lat DECIMAL(10, 8) DEFAULT 0,
  lng DECIMAL(11, 8) DEFAULT 0,
  population INTEGER DEFAULT 0,
  area_sqkm DECIMAL(8, 2) DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Tickets table (main civic issues)
CREATE TABLE IF NOT EXISTS tickets (
  id SERIAL PRIMARY KEY,
  ticket_no VARCHAR(20) NOT NULL UNIQUE,
  category VARCHAR(20) NOT NULL CHECK (category IN ('ROADS', 'ELECTRICITY', 'SANITATION', 'WATER', 'PARKS', 'GENERAL')),
  description TEXT NOT NULL,
  lat DECIMAL(10, 8) NOT NULL,
  lng DECIMAL(11, 8) NOT NULL,
  address VARCHAR(255),
  priority VARCHAR(10) NOT NULL DEFAULT 'MEDIUM' CHECK (priority IN ('LOW', 'MEDIUM', 'HIGH', 'CRITICAL')),
  status VARCHAR(20) NOT NULL DEFAULT 'PENDING' CHECK (status IN ('PENDING', 'ACKNOWLEDGED', 'IN_PROGRESS', 'RESOLVED', 'VERIFIED', 'CLOSED')),
  
  -- Citizen information (optional, for privacy)
  citizen_name VARCHAR(100),
  citizen_phone VARCHAR(15),
  
  -- System tracking
  department_id INTEGER NOT NULL REFERENCES departments(id),
  panchayat_id INTEGER NOT NULL REFERENCES panchayats(id),
  created_by INTEGER REFERENCES users(id), -- For admin-created tickets
  assigned_to INTEGER REFERENCES users(id),
  
  -- SLA and escalation
  sla_due TIMESTAMPTZ NOT NULL,
  escalated BOOLEAN DEFAULT false,
  escalated_at TIMESTAMPTZ,
  
  -- Source tracking (mobile app, web, webhook, etc.)
  source VARCHAR(20) DEFAULT 'WEB',
  
  -- Timestamps
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Ticket history for audit trail
CREATE TABLE IF NOT EXISTS ticket_history (
  id SERIAL PRIMARY KEY,
  ticket_id INTEGER NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  from_status VARCHAR(20),
  to_status VARCHAR(20) NOT NULL,
  comment TEXT,
  changed_by INTEGER REFERENCES users(id),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Media files (photos, audio recordings)
CREATE TABLE IF NOT EXISTS media (
  id SERIAL PRIMARY KEY,
  ticket_id INTEGER NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  filename VARCHAR(255) NOT NULL,
  original_name VARCHAR(255),
  url VARCHAR(500) NOT NULL,
  thumbnail_url VARCHAR(500),
  type VARCHAR(10) NOT NULL CHECK (type IN ('IMAGE', 'AUDIO', 'VIDEO')),
  size BIGINT DEFAULT 0,
  mime_type VARCHAR(100),
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Notifications system
CREATE TABLE IF NOT EXISTS notifications (
  id SERIAL PRIMARY KEY,
  recipient_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title VARCHAR(200) NOT NULL,
  message TEXT NOT NULL,
  type VARCHAR(20) DEFAULT 'INFO' CHECK (type IN ('INFO', 'WARNING', 'ERROR', 'SUCCESS')),
  channel VARCHAR(20) DEFAULT 'WEB' CHECK (channel IN ('WEB', 'EMAIL', 'SMS', 'PUSH')),
  read_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_tickets_department ON tickets(department_id);
CREATE INDEX IF NOT EXISTS idx_tickets_panchayat ON tickets(panchayat_id);
CREATE INDEX IF NOT EXISTS idx_tickets_status ON tickets(status);
CREATE INDEX IF NOT EXISTS idx_tickets_assigned ON tickets(assigned_to);
CREATE INDEX IF NOT EXISTS idx_tickets_created_at ON tickets(created_at);
CREATE INDEX IF NOT EXISTS idx_tickets_location ON tickets(lat, lng);
CREATE INDEX IF NOT EXISTS idx_tickets_sla_due ON tickets(sla_due);

CREATE INDEX IF NOT EXISTS idx_ticket_history_ticket ON ticket_history(ticket_id);
CREATE INDEX IF NOT EXISTS idx_media_ticket ON media(ticket_id);
CREATE INDEX IF NOT EXISTS idx_notifications_recipient ON notifications(recipient_id);
CREATE INDEX IF NOT EXISTS idx_notifications_unread ON notifications(recipient_id, read_at) WHERE read_at IS NULL;

-- Enable Row Level Security (RLS)
ALTER TABLE departments ENABLE ROW LEVEL SECURITY;
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE panchayats ENABLE ROW LEVEL SECURITY;
ALTER TABLE tickets ENABLE ROW LEVEL SECURITY;
ALTER TABLE ticket_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE media ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- RLS Policies (Note: These are basic examples - adjust based on your auth system)

-- Departments: All authenticated users can read
CREATE POLICY "All users can read departments" ON departments
  FOR SELECT TO authenticated USING (true);

-- Users: Users can read their own data, admins can read all
CREATE POLICY "Users can read own data" ON users
  FOR SELECT TO authenticated 
  USING (id = current_user_id() OR current_user_role() = 'SUPER_ADMIN');

-- Panchayats: All authenticated users can read
CREATE POLICY "All users can read panchayats" ON panchayats
  FOR SELECT TO authenticated USING (true);

-- Tickets: Role-based access
CREATE POLICY "Super admins can access all tickets" ON tickets
  FOR ALL TO authenticated 
  USING (current_user_role() = 'SUPER_ADMIN');

CREATE POLICY "Dept officers can access their department tickets" ON tickets
  FOR ALL TO authenticated 
  USING (current_user_role() = 'DEPT_OFFICER' AND department_id = current_user_dept());

CREATE POLICY "Field officers can access assigned tickets" ON tickets
  FOR ALL TO authenticated 
  USING (current_user_role() = 'FIELD_OFFICER' AND assigned_to = current_user_id());

-- Notifications: Users can only access their own notifications
CREATE POLICY "Users can access own notifications" ON notifications
  FOR ALL TO authenticated 
  USING (recipient_id = current_user_id());

-- Helper functions for RLS (these would be implemented based on your JWT claims)
-- For now, we'll create placeholder functions

CREATE OR REPLACE FUNCTION current_user_id() RETURNS INTEGER AS $$
BEGIN
  -- In a real implementation, extract from JWT token
  RETURN 1; -- Placeholder
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION current_user_role() RETURNS TEXT AS $$
BEGIN
  -- In a real implementation, extract from JWT token
  RETURN 'SUPER_ADMIN'; -- Placeholder
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

CREATE OR REPLACE FUNCTION current_user_dept() RETURNS INTEGER AS $$
BEGIN
  -- In a real implementation, extract from JWT token
  RETURN 1; -- Placeholder
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger to update updated_at timestamp
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply update triggers
CREATE TRIGGER update_departments_updated_at BEFORE UPDATE ON departments
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON users
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_panchayats_updated_at BEFORE UPDATE ON panchayats
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_tickets_updated_at BEFORE UPDATE ON tickets
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();