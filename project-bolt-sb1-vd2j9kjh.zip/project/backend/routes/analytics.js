const express = require('express');
const { getDb } = require('../config/database');
const { authenticateToken, authorizeDepartment } = require('../middleware/auth');

const router = express.Router();

// Get department analytics
router.get('/department/:id', authenticateToken, authorizeDepartment, async (req, res) => {
  try {
    const departmentId = req.params.id;
    const { from, to } = req.query;
    const db = getDb();

    // Date range
    const fromDate = from || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(); // 30 days ago
    const toDate = to || new Date().toISOString();

    // Overall statistics
    const overallStats = await db.query(`
      SELECT 
        COUNT(*) as total_tickets,
        COUNT(CASE WHEN status = 'PENDING' THEN 1 END) as pending,
        COUNT(CASE WHEN status = 'ACKNOWLEDGED' THEN 1 END) as acknowledged,
        COUNT(CASE WHEN status = 'IN_PROGRESS' THEN 1 END) as in_progress,
        COUNT(CASE WHEN status = 'RESOLVED' THEN 1 END) as resolved,
        COUNT(CASE WHEN status = 'VERIFIED' THEN 1 END) as verified,
        COUNT(CASE WHEN status = 'CLOSED' THEN 1 END) as closed,
        COUNT(CASE WHEN status = 'PENDING' AND sla_due < NOW() THEN 1 END) as overdue,
        AVG(CASE WHEN status IN ('RESOLVED', 'VERIFIED', 'CLOSED') 
            THEN EXTRACT(EPOCH FROM (updated_at - created_at))/3600 
            END) as avg_resolution_hours
      FROM tickets 
      WHERE department_id = $1 AND created_at BETWEEN $2 AND $3
    `, [departmentId, fromDate, toDate]);

    // Daily trend
    const dailyTrend = await db.query(`
      SELECT 
        DATE(created_at) as date,
        COUNT(*) as created,
        COUNT(CASE WHEN status IN ('RESOLVED', 'VERIFIED', 'CLOSED') THEN 1 END) as resolved
      FROM tickets 
      WHERE department_id = $1 AND created_at BETWEEN $2 AND $3
      GROUP BY DATE(created_at)
      ORDER BY date
    `, [departmentId, fromDate, toDate]);

    // Priority breakdown
    const priorityBreakdown = await db.query(`
      SELECT 
        priority,
        COUNT(*) as count,
        COUNT(CASE WHEN status IN ('RESOLVED', 'VERIFIED', 'CLOSED') THEN 1 END) as resolved
      FROM tickets 
      WHERE department_id = $1 AND created_at BETWEEN $2 AND $3
      GROUP BY priority
      ORDER BY 
        CASE priority 
          WHEN 'CRITICAL' THEN 1 
          WHEN 'HIGH' THEN 2 
          WHEN 'MEDIUM' THEN 3 
          WHEN 'LOW' THEN 4 
        END
    `, [departmentId, fromDate, toDate]);

    // Category breakdown
    const categoryBreakdown = await db.query(`
      SELECT 
        category,
        COUNT(*) as count,
        AVG(CASE WHEN status IN ('RESOLVED', 'VERIFIED', 'CLOSED') 
            THEN EXTRACT(EPOCH FROM (updated_at - created_at))/3600 
            END) as avg_resolution_hours
      FROM tickets 
      WHERE department_id = $1 AND created_at BETWEEN $2 AND $3
      GROUP BY category
      ORDER BY count DESC
    `, [departmentId, fromDate, toDate]);

    // Top performing panchayats
    const topPanchayats = await db.query(`
      SELECT 
        p.id, p.name, p.district,
        COUNT(t.id) as total_tickets,
        COUNT(CASE WHEN t.status IN ('RESOLVED', 'VERIFIED', 'CLOSED') THEN 1 END) as resolved_tickets,
        CASE 
          WHEN COUNT(t.id) > 0 
          THEN ROUND((COUNT(CASE WHEN t.status IN ('RESOLVED', 'VERIFIED', 'CLOSED') THEN 1 END) * 100.0 / COUNT(t.id)), 2)
          ELSE 0 
        END as resolution_rate
      FROM panchayats p
      LEFT JOIN tickets t ON p.id = t.panchayat_id 
        AND t.department_id = $1 
        AND t.created_at BETWEEN $2 AND $3
      GROUP BY p.id, p.name, p.district
      HAVING COUNT(t.id) > 0
      ORDER BY resolution_rate DESC, total_tickets DESC
      LIMIT 10
    `, [departmentId, fromDate, toDate]);

    // Officer performance
    const officerPerformance = await db.query(`
      SELECT 
        u.id, u.name,
        COUNT(t.id) as assigned_tickets,
        COUNT(CASE WHEN t.status IN ('RESOLVED', 'VERIFIED', 'CLOSED') THEN 1 END) as resolved_tickets,
        AVG(CASE WHEN t.status IN ('RESOLVED', 'VERIFIED', 'CLOSED') 
            THEN EXTRACT(EPOCH FROM (t.updated_at - t.created_at))/3600 
            END) as avg_resolution_hours
      FROM users u
      LEFT JOIN tickets t ON u.id = t.assigned_to 
        AND t.department_id = $1 
        AND t.created_at BETWEEN $2 AND $3
      WHERE u.role = 'FIELD_OFFICER' AND u.department_id = $1 AND u.active = true
      GROUP BY u.id, u.name
      ORDER BY resolved_tickets DESC
    `, [departmentId, fromDate, toDate]);

    // SLA performance
    const slaPerformance = await db.query(`
      SELECT 
        COUNT(CASE WHEN status IN ('RESOLVED', 'VERIFIED', 'CLOSED') AND updated_at <= sla_due THEN 1 END) as within_sla,
        COUNT(CASE WHEN status IN ('RESOLVED', 'VERIFIED', 'CLOSED') AND updated_at > sla_due THEN 1 END) as beyond_sla,
        COUNT(CASE WHEN status NOT IN ('RESOLVED', 'VERIFIED', 'CLOSED') AND NOW() > sla_due THEN 1 END) as overdue
      FROM tickets 
      WHERE department_id = $1 AND created_at BETWEEN $2 AND $3
    `, [departmentId, fromDate, toDate]);

    res.json({
      overview: overallStats.rows[0],
      dailyTrend: dailyTrend.rows,
      priorityBreakdown: priorityBreakdown.rows,
      categoryBreakdown: categoryBreakdown.rows,
      topPanchayats: topPanchayats.rows,
      officerPerformance: officerPerformance.rows,
      slaPerformance: slaPerformance.rows[0],
      dateRange: { from: fromDate, to: toDate }
    });
  } catch (error) {
    console.error('Get department analytics error:', error);
    res.status(500).json({ error: 'Failed to fetch department analytics' });
  }
});

// Get panchayat analytics
router.get('/panchayat/:id', authenticateToken, async (req, res) => {
  try {
    const panchayatId = req.params.id;
    const { departmentId, from, to } = req.query;
    const db = getDb();

    // Date range
    const fromDate = from || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
    const toDate = to || new Date().toISOString();

    let whereClause = 'WHERE panchayat_id = $1 AND created_at BETWEEN $2 AND $3';
    let params = [panchayatId, fromDate, toDate];

    if (departmentId) {
      whereClause += ' AND department_id = $4';
      params.push(departmentId);
    }

    // Overall statistics
    const overallStats = await db.query(`
      SELECT 
        COUNT(*) as total_tickets,
        COUNT(CASE WHEN status = 'PENDING' THEN 1 END) as pending,
        COUNT(CASE WHEN status = 'ACKNOWLEDGED' THEN 1 END) as acknowledged,
        COUNT(CASE WHEN status = 'IN_PROGRESS' THEN 1 END) as in_progress,
        COUNT(CASE WHEN status = 'RESOLVED' THEN 1 END) as resolved,
        COUNT(CASE WHEN status = 'VERIFIED' THEN 1 END) as verified,
        COUNT(CASE WHEN status = 'CLOSED' THEN 1 END) as closed,
        COUNT(CASE WHEN status = 'PENDING' AND sla_due < NOW() THEN 1 END) as overdue,
        AVG(CASE WHEN status IN ('RESOLVED', 'VERIFIED', 'CLOSED') 
            THEN EXTRACT(EPOCH FROM (updated_at - created_at))/3600 
            END) as avg_resolution_hours
      FROM tickets 
      ${whereClause}
    `, params);

    // Daily trend
    const dailyTrend = await db.query(`
      SELECT 
        DATE(created_at) as date,
        COUNT(*) as created,
        COUNT(CASE WHEN status IN ('RESOLVED', 'VERIFIED', 'CLOSED') THEN 1 END) as resolved
      FROM tickets 
      ${whereClause}
      GROUP BY DATE(created_at)
      ORDER BY date
    `, params);

    // Department breakdown (if not filtering by department)
    let departmentBreakdown = [];
    if (!departmentId) {
      const deptResult = await db.query(`
        SELECT 
          d.name as department_name,
          COUNT(t.id) as count,
          COUNT(CASE WHEN t.status IN ('RESOLVED', 'VERIFIED', 'CLOSED') THEN 1 END) as resolved
        FROM departments d
        LEFT JOIN tickets t ON d.id = t.department_id 
          AND t.panchayat_id = $1 
          AND t.created_at BETWEEN $2 AND $3
        GROUP BY d.id, d.name
        ORDER BY count DESC
      `, [panchayatId, fromDate, toDate]);
      departmentBreakdown = deptResult.rows;
    }

    // Category breakdown
    const categoryBreakdown = await db.query(`
      SELECT 
        category,
        COUNT(*) as count,
        AVG(CASE WHEN status IN ('RESOLVED', 'VERIFIED', 'CLOSED') 
            THEN EXTRACT(EPOCH FROM (updated_at - created_at))/3600 
            END) as avg_resolution_hours
      FROM tickets 
      ${whereClause}
      GROUP BY category
      ORDER BY count DESC
    `, params);

    // Priority breakdown
    const priorityBreakdown = await db.query(`
      SELECT 
        priority,
        COUNT(*) as count,
        COUNT(CASE WHEN status IN ('RESOLVED', 'VERIFIED', 'CLOSED') THEN 1 END) as resolved
      FROM tickets 
      ${whereClause}
      GROUP BY priority
      ORDER BY 
        CASE priority 
          WHEN 'CRITICAL' THEN 1 
          WHEN 'HIGH' THEN 2 
          WHEN 'MEDIUM' THEN 3 
          WHEN 'LOW' THEN 4 
        END
    `, params);

    res.json({
      overview: overallStats.rows[0],
      dailyTrend: dailyTrend.rows,
      departmentBreakdown: departmentBreakdown,
      categoryBreakdown: categoryBreakdown.rows,
      priorityBreakdown: priorityBreakdown.rows,
      dateRange: { from: fromDate, to: toDate }
    });
  } catch (error) {
    console.error('Get panchayat analytics error:', error);
    res.status(500).json({ error: 'Failed to fetch panchayat analytics' });
  }
});

// Export analytics data
router.get('/export/:type/:id', authenticateToken, async (req, res) => {
  try {
    const { type, id } = req.params; // 'department' or 'panchayat'
    const { format = 'csv', from, to } = req.query;
    
    if (format !== 'csv') {
      return res.status(400).json({ error: 'Only CSV export is currently supported' });
    }

    const db = getDb();
    const fromDate = from || new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
    const toDate = to || new Date().toISOString();

    let query, params;
    
    if (type === 'department') {
      query = `
        SELECT 
          t.ticket_no, t.category, t.description, t.priority, t.status,
          t.created_at, t.updated_at, t.lat, t.lng, t.address,
          p.name as panchayat_name, p.district,
          u.name as assigned_to_name,
          EXTRACT(EPOCH FROM (t.updated_at - t.created_at))/3600 as resolution_hours
        FROM tickets t
        LEFT JOIN panchayats p ON t.panchayat_id = p.id
        LEFT JOIN users u ON t.assigned_to = u.id
        WHERE t.department_id = $1 AND t.created_at BETWEEN $2 AND $3
        ORDER BY t.created_at DESC
      `;
      params = [id, fromDate, toDate];
    } else if (type === 'panchayat') {
      query = `
        SELECT 
          t.ticket_no, t.category, t.description, t.priority, t.status,
          t.created_at, t.updated_at, t.lat, t.lng, t.address,
          d.name as department_name,
          u.name as assigned_to_name,
          EXTRACT(EPOCH FROM (t.updated_at - t.created_at))/3600 as resolution_hours
        FROM tickets t
        LEFT JOIN departments d ON t.department_id = d.id
        LEFT JOIN users u ON t.assigned_to = u.id
        WHERE t.panchayat_id = $1 AND t.created_at BETWEEN $2 AND $3
        ORDER BY t.created_at DESC
      `;
      params = [id, fromDate, toDate];
    } else {
      return res.status(400).json({ error: 'Invalid export type' });
    }

    const result = await db.query(query, params);
    
    // Convert to CSV
    if (result.rows.length === 0) {
      return res.status(404).json({ error: 'No data found for the specified criteria' });
    }

    const headers = Object.keys(result.rows[0]);
    const csvContent = [
      headers.join(','),
      ...result.rows.map(row => 
        headers.map(header => {
          const value = row[header];
          // Handle null/undefined values and escape commas
          return value === null || value === undefined ? '' : 
                 typeof value === 'string' && value.includes(',') ? `"${value}"` : value;
        }).join(',')
      )
    ].join('\n');

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="${type}_${id}_export_${new Date().toISOString().split('T')[0]}.csv"`);
    res.send(csvContent);
  } catch (error) {
    console.error('Export analytics error:', error);
    res.status(500).json({ error: 'Failed to export analytics data' });
  }
});

module.exports = router;