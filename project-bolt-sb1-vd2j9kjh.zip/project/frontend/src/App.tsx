import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuthStore } from './stores/authStore';
import { useWebSocket } from './hooks/useWebSocket';
import LoginPage from './pages/LoginPage';
import DashboardLayout from './components/Layout/DashboardLayout';
import GeneralDashboard from './pages/GeneralDashboard';
import DepartmentDashboard from './pages/DepartmentDashboard';
import PanchayatDashboard from './pages/PanchayatDashboard';
import IssueDetail from './pages/IssueDetail';
import NotificationsPage from './pages/NotificationsPage';
import LoadingSpinner from './components/UI/LoadingSpinner';

function App() {
  const { user, isLoading, isAuthenticated } = useAuthStore();
  
  // Initialize WebSocket for authenticated users
  useWebSocket();

  if (isLoading) {
    return <LoadingSpinner />;
  }

  if (!isAuthenticated || !user) {
    return <LoginPage />;
  }

  return (
    <Routes>
      <Route path="/" element={<DashboardLayout />}>
        <Route index element={<GeneralDashboard />} />
        <Route path="department/:departmentId" element={<DepartmentDashboard />} />
        <Route path="department/:departmentId/panchayat/:panchayatId" element={<PanchayatDashboard />} />
        <Route path="ticket/:ticketId" element={<IssueDetail />} />
        <Route path="notifications" element={<NotificationsPage />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default App;