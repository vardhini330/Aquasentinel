import { create } from 'zustand';
import { api } from '../services/api';
import toast from 'react-hot-toast';

export interface Notification {
  id: number;
  title: string;
  message: string;
  type: 'INFO' | 'WARNING' | 'ERROR' | 'SUCCESS';
  read_at: string | null;
  created_at: string;
}

interface NotificationState {
  notifications: Notification[];
  unreadCount: number;
  isLoading: boolean;
}

interface NotificationActions {
  fetchNotifications: () => Promise<void>;
  markAsRead: (id: number) => Promise<void>;
  markAllAsRead: () => Promise<void>;
  addNotification: (notification: Notification) => void;
  getUnreadCount: () => Promise<void>;
}

export const useNotificationStore = create<NotificationState & NotificationActions>((set, get) => ({
  notifications: [],
  unreadCount: 0,
  isLoading: false,

  fetchNotifications: async () => {
    try {
      set({ isLoading: true });
      const response = await api.get('/notifications');
      
      set({
        notifications: response.data.notifications,
        isLoading: false
      });
      
      // Update unread count
      await get().getUnreadCount();
    } catch (error: any) {
      set({ isLoading: false });
      console.error('Fetch notifications failed:', error);
    }
  },

  markAsRead: async (id: number) => {
    try {
      await api.patch(`/notifications/${id}/read`);
      
      set(state => ({
        notifications: state.notifications.map(notif =>
          notif.id === id ? { ...notif, read_at: new Date().toISOString() } : notif
        ),
        unreadCount: Math.max(0, state.unreadCount - 1)
      }));
    } catch (error: any) {
      console.error('Mark notification as read failed:', error);
      toast.error('Failed to mark notification as read');
    }
  },

  markAllAsRead: async () => {
    try {
      await api.patch('/notifications/read-all');
      
      set(state => ({
        notifications: state.notifications.map(notif => ({
          ...notif,
          read_at: notif.read_at || new Date().toISOString()
        })),
        unreadCount: 0
      }));
      
      toast.success('All notifications marked as read');
    } catch (error: any) {
      console.error('Mark all notifications as read failed:', error);
      toast.error('Failed to mark all notifications as read');
    }
  },

  addNotification: (notification: Notification) => {
    set(state => ({
      notifications: [notification, ...state.notifications],
      unreadCount: notification.read_at ? state.unreadCount : state.unreadCount + 1
    }));

    // Show toast notification
    const toastOptions = {
      duration: 6000,
      icon: notification.type === 'ERROR' ? '❌' : 
            notification.type === 'WARNING' ? '⚠️' : 
            notification.type === 'SUCCESS' ? '✅' : '📢'
    };

    toast(notification.message, toastOptions);
  },

  getUnreadCount: async () => {
    try {
      const response = await api.get('/notifications/counts');
      set({ unreadCount: response.data.unread });
    } catch (error: any) {
      console.error('Get notification counts failed:', error);
    }
  }
}));