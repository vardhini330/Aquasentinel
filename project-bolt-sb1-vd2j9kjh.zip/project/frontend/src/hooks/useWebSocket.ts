import { useEffect, useRef } from 'react';
import { useAuthStore } from '../stores/authStore';
import { useNotificationStore } from '../stores/notificationStore';
import toast from 'react-hot-toast';

export const useWebSocket = () => {
  const { user, token, isAuthenticated } = useAuthStore();
  const { addNotification } = useNotificationStore();
  const ws = useRef<WebSocket | null>(null);
  const reconnectTimer = useRef<NodeJS.Timeout | null>(null);
  const reconnectAttempts = useRef(0);
  const maxReconnectAttempts = 5;

  const connect = () => {
    if (!isAuthenticated || !token || ws.current?.readyState === WebSocket.OPEN) {
      return;
    }

    try {
      const wsUrl = import.meta.env.VITE_WS_URL || 'ws://localhost:5000';
      const url = `${wsUrl}/ws?token=${encodeURIComponent(token)}`;
      
      ws.current = new WebSocket(url);

      ws.current.onopen = () => {
        console.log('WebSocket connected');
        reconnectAttempts.current = 0;
        
        // Subscribe to relevant channels based on user role
        if (user) {
          const subscriptions = [`user:${user.id}`];
          
          if (user.role === 'DEPT_OFFICER' && user.department) {
            subscriptions.push(`dept:${user.department.id}`);
          }
          
          ws.current?.send(JSON.stringify({
            type: 'subscribe',
            payload: { channels: subscriptions }
          }));
        }
      };

      ws.current.onmessage = (event) => {
        try {
          const data = JSON.parse(event.data);
          handleWebSocketMessage(data);
        } catch (error) {
          console.error('WebSocket message parsing error:', error);
        }
      };

      ws.current.onclose = (event) => {
        console.log('WebSocket disconnected:', event.code);
        
        // Attempt to reconnect if not intentionally closed
        if (event.code !== 1000 && reconnectAttempts.current < maxReconnectAttempts) {
          const delay = Math.min(1000 * Math.pow(2, reconnectAttempts.current), 30000);
          console.log(`Attempting to reconnect in ${delay}ms...`);
          
          reconnectTimer.current = setTimeout(() => {
            reconnectAttempts.current++;
            connect();
          }, delay);
        }
      };

      ws.current.onerror = (error) => {
        console.error('WebSocket error:', error);
      };

    } catch (error) {
      console.error('WebSocket connection failed:', error);
    }
  };

  const disconnect = () => {
    if (reconnectTimer.current) {
      clearTimeout(reconnectTimer.current);
      reconnectTimer.current = null;
    }
    
    if (ws.current) {
      ws.current.close(1000, 'Intentional disconnect');
      ws.current = null;
    }
  };

  const handleWebSocketMessage = (data: any) => {
    switch (data.event || data.type) {
      case 'connected':
        console.log('WebSocket connection established:', data.message);
        break;

      case 'ticket.created':
        handleNewTicket(data.ticket);
        break;

      case 'ticket.updated':
        handleTicketUpdate(data.ticket);
        break;

      case 'ticket.assigned':
        handleTicketAssignment(data.ticket);
        break;

      case 'notification.new':
        addNotification(data.notification);
        break;

      case 'subscribed':
        console.log('Subscribed to channels:', data.subscriptions);
        break;

      case 'pong':
        console.log('WebSocket pong received');
        break;

      default:
        console.log('Unknown WebSocket message:', data);
    }
  };

  const handleNewTicket = (ticket: any) => {
    toast(`New ${ticket.priority} priority ticket: ${ticket.ticket_no}`, {
      icon: '🎫',
      duration: 6000,
      style: {
        backgroundColor: ticket.priority === 'CRITICAL' ? '#FEF2F2' : '#F0F9FF',
        borderColor: ticket.priority === 'CRITICAL' ? '#FECACA' : '#BFDBFE'
      }
    });

    // Trigger a refetch of tickets if on relevant page
    window.dispatchEvent(new CustomEvent('ticket:created', { detail: ticket }));
  };

  const handleTicketUpdate = (ticket: any) => {
    toast(`Ticket ${ticket.ticket_no} status changed to ${ticket.status}`, {
      icon: '📝',
      duration: 4000
    });

    // Trigger a refetch of tickets
    window.dispatchEvent(new CustomEvent('ticket:updated', { detail: ticket }));
  };

  const handleTicketAssignment = (ticket: any) => {
    if (user?.id === ticket.assigned_to) {
      toast(`Ticket ${ticket.ticket_no} has been assigned to you`, {
        icon: '👤',
        duration: 5000,
        style: {
          backgroundColor: '#F0FDF4',
          borderColor: '#BBF7D0'
        }
      });
    }

    window.dispatchEvent(new CustomEvent('ticket:assigned', { detail: ticket }));
  };

  // Send ping every 30 seconds to keep connection alive
  useEffect(() => {
    const pingInterval = setInterval(() => {
      if (ws.current?.readyState === WebSocket.OPEN) {
        ws.current.send(JSON.stringify({ type: 'ping' }));
      }
    }, 30000);

    return () => clearInterval(pingInterval);
  }, []);

  // Connect/disconnect based on authentication status
  useEffect(() => {
    if (isAuthenticated && token) {
      connect();
    } else {
      disconnect();
    }

    return () => {
      disconnect();
    };
  }, [isAuthenticated, token]);

  // Subscribe to additional channels
  const subscribe = (channels: string[]) => {
    if (ws.current?.readyState === WebSocket.OPEN) {
      ws.current.send(JSON.stringify({
        type: 'subscribe',
        payload: { channels }
      }));
    }
  };

  // Unsubscribe from channels
  const unsubscribe = (channels: string[]) => {
    if (ws.current?.readyState === WebSocket.OPEN) {
      ws.current.send(JSON.stringify({
        type: 'unsubscribe',
        payload: { channels }
      }));
    }
  };

  return {
    isConnected: ws.current?.readyState === WebSocket.OPEN,
    subscribe,
    unsubscribe
  };
};