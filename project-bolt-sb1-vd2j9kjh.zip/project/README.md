# Jharkhand Civic Issue Management Portal

A comprehensive full-stack web application for managing civic issues reported by citizens of Jharkhand. This system enables government officers to efficiently track, assign, and resolve civic complaints with real-time updates and analytics.

## 🏗 Architecture Overview

- **Frontend**: React 18 + TypeScript + Tailwind CSS
- **Backend**: Node.js + Express + PostgreSQL + Redis
- **Real-time**: WebSocket connections for live updates
- **Authentication**: JWT-based with refresh tokens
- **Database**: PostgreSQL with PostGIS for geospatial queries
- **Caching & Pub/Sub**: Redis for real-time events
- **Containerization**: Docker + Docker Compose

## 🚀 Quick Start

### Prerequisites

- Docker and Docker Compose
- Node.js 18+ (for local development)
- Git

### Using Docker (Recommended)

1. **Clone and Start**
   ```bash
   git clone <repository-url>
   cd jharkhand-civic-portal
   docker-compose up -d
   ```

2. **Initialize Database**
   ```bash
   # Wait for services to start, then seed the database
   docker-compose exec backend npm run seed
   ```

3. **Access the Application**
   - Frontend: http://localhost:5173
   - Backend API: http://localhost:5000
   - Health Check: http://localhost:5000/health

### Local Development Setup

1. **Database Setup**
   ```bash
   # Start PostgreSQL and Redis
   docker-compose up postgres redis -d
   
   # Set environment variables
   export DATABASE_URL="postgresql://postgres:password@localhost:5432/jharkhand_civic"
   export REDIS_URL="redis://localhost:6379"
   export JWT_SECRET="jharkhand_civic_secret_2024"
   ```

2. **Backend Setup**
   ```bash
   cd backend
   npm install
   npm run seed    # Initialize database with sample data
   npm run dev     # Start development server
   ```

3. **Frontend Setup**
   ```bash
   cd frontend
   npm install
   npm run dev     # Start development server
   ```

## 🔐 Default Login Credentials

| Role | Email | Password | Description |
|------|-------|----------|-------------|
| Super Admin | admin@jharkhand.gov.in | password123 | Full system access |
| Dept Officer | sanitation@jharkhand.gov.in | password123 | Sanitation department |
| Field Officer | rajesh.field@jharkhand.gov.in | password123 | Field operations |

## 🏛 System Features

### Core Functionality
- **Multi-role Authentication** (Super Admin, Department Officer, Field Officer)
- **Department-wise Issue Management** (Roads, Electricity, Sanitation, Water, Parks, General)
- **Real-time Updates** via WebSocket connections
- **Geospatial Issue Mapping** with clustering
- **SLA Tracking** with automatic escalations
- **Multi-media Support** (photos, audio recordings)
- **Audit Trail** for all ticket actions
- **Analytics & Reporting** with export capabilities
- **Bilingual Support** (English/Hindi)

### User Workflows

#### 1. Login Flow
- Secure JWT authentication
- Role-based dashboard redirection
- Remember me functionality
- Password reset capability (mocked)

#### 2. General Dashboard
- Department overview cards with statistics
- Chief Minister photo display
- Quick navigation to department-specific views
- Real-time notification bell

#### 3. Department Dashboard
- Real-time issue statistics
- Interactive map with clustered pins
- Filterable issues table
- Performance analytics
- CSV export functionality

#### 4. Panchayat Dashboard
- Panchayat-level issue filtering
- Localized statistics and trends
- Officer performance metrics

#### 5. Issue Management
- Complete issue lifecycle tracking
- Media attachments (photos/audio)
- Assignment to field officers
- Status updates with comments
- Escalation mechanisms

## 🔧 API Endpoints

### Authentication
- `POST /api/auth/login` - User login
- `POST /api/auth/refresh` - Refresh access token
- `GET /api/auth/me` - Get current user profile

### Departments
- `GET /api/departments` - List all departments
- `GET /api/departments/:id` - Get department details
- `GET /api/departments/:id/stats` - Department statistics

### Tickets (Issues)
- `GET /api/tickets` - List tickets with filtering
- `GET /api/tickets/:id` - Get ticket details
- `POST /api/tickets/public` - Create ticket (public endpoint)
- `POST /api/tickets/:id/status` - Update ticket status
- `POST /api/tickets/:id/assign` - Assign ticket to officer

### Analytics
- `GET /api/analytics/department/:id` - Department analytics
- `GET /api/analytics/panchayat/:id` - Panchayat analytics
- `GET /api/analytics/export/:type/:id` - Export data as CSV

### WebSocket Events
- `ticket.created` - New ticket created
- `ticket.updated` - Ticket status changed
- `ticket.assigned` - Ticket assigned to officer
- `notification.new` - New notification

## 🗄 Database Schema

### Core Tables
- **departments** - Government departments
- **users** - System users with role-based access
- **panchayats** - Administrative divisions
- **tickets** - Civic issues with complete lifecycle
- **ticket_history** - Audit trail for all changes
- **media** - File attachments
- **notifications** - User notifications

### Sample Data Included
- 6 Government departments
- 15 Jharkhand panchayats with coordinates
- 5 Sample users (different roles)
- 20+ Sample tickets across departments
- Complete audit history

## 🌐 Frontend Architecture

### State Management
- **Zustand** for application state
- **Auth Store** for user authentication
- **Notification Store** for real-time notifications

### Key Components
- **Layout System** with responsive design
- **Interactive Maps** using React Leaflet
- **Chart Components** with Recharts
- **Form Components** with validation
- **Real-time WebSocket** integration

### Responsive Design
- Mobile-first approach
- Tailwind CSS for styling
- Accessible components
- Print-friendly styles

## 🔒 Security Features

- **JWT Authentication** with refresh tokens
- **Role-based Access Control** (RBAC)
- **Row Level Security** (RLS) in database
- **Input Validation** and sanitization
- **Rate Limiting** on public endpoints
- **CORS Protection**
- **SQL Injection Prevention**
- **XSS Protection**

## 📊 Real-time Features

### WebSocket Integration
- Automatic reconnection with exponential backoff
- Channel-based subscriptions
- Real-time ticket updates
- Live notification delivery
- Connection health monitoring

### Notification System
- In-app notifications
- Toast messages for actions
- Unread count tracking
- Notification history

## 🌍 Internationalization

### Supported Languages
- **English** (default)
- **Hindi** (हिन्दी)

### Implementation
- Complete UI translation
- Right-to-left text support
- Cultural date/time formatting
- Accessible language switching

## 📈 Analytics & Reporting

### Department Analytics
- Issue volume trends
- Resolution performance
- SLA compliance
- Officer productivity
- Priority distribution

### Export Capabilities
- CSV export for all data
- Date range filtering
- Department/panchayat level exports
- Print-friendly reports

## 🐳 Docker Configuration

### Services
- **postgres** - PostgreSQL with PostGIS
- **redis** - Redis for caching and pub/sub
- **backend** - Node.js API server
- **frontend** - React development server

### Environment Variables

```bash
# Database
DATABASE_URL=postgresql://postgres:password@postgres:5432/jharkhand_civic

# Redis
REDIS_URL=redis://redis:6379

# JWT Secrets
JWT_SECRET=jharkhand_civic_secret_2024
JWT_REFRESH_SECRET=jharkhand_civic_refresh_secret_2024

# CORS
CORS_ORIGIN=http://localhost:5173

# Frontend
VITE_API_URL=http://localhost:5000
VITE_WS_URL=ws://localhost:5000
```

## 🧪 Testing

### Backend Testing
```bash
cd backend
npm test
```

### Frontend Testing
```bash
cd frontend
npm test
```

### Integration Testing
- WebSocket connection testing
- API endpoint validation
- Authentication flow testing
- Real-time event testing

## 🚀 Production Deployment

### Build for Production

```bash
# Build frontend
cd frontend
npm run build

# Backend is production-ready
cd backend
npm start
```

### Production Considerations
- Use HTTPS in production
- Configure proper CORS origins
- Set up Redis persistence
- Configure database backups
- Enable logging and monitoring
- Set up SSL certificates

## 🔧 Development

### Adding New Features

1. **Backend**: Add routes in `/backend/routes/`
2. **Frontend**: Add components in `/frontend/src/components/`
3. **Database**: Create migration files in `/backend/migrations/`
4. **WebSocket**: Handle events in `/backend/websocket/handler.js`

### Code Style
- ESLint configuration included
- Prettier for code formatting
- TypeScript strict mode
- Conventional commit messages

## 🐛 Troubleshooting

### Common Issues

1. **Database Connection Failed**
   ```bash
   # Check if PostgreSQL is running
   docker-compose ps postgres
   
   # Reset database
   docker-compose down -v
   docker-compose up postgres -d
   ```

2. **WebSocket Connection Issues**
   ```bash
   # Check Redis connection
   docker-compose ps redis
   
   # Clear Redis data
   docker-compose exec redis redis-cli flushall
   ```

3. **Port Conflicts**
   ```bash
   # Check if ports are in use
   lsof -i :5000  # Backend
   lsof -i :5173  # Frontend
   lsof -i :5432  # PostgreSQL
   lsof -i :6379  # Redis
   ```

## 📝 API Documentation

Complete OpenAPI/Swagger documentation is available at:
- Development: http://localhost:5000/api-docs
- API Spec: `/docs/openapi.yaml`

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open Pull Request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🙏 Acknowledgments

- Government of Jharkhand for requirements
- React and Node.js communities
- Open source contributors

---

**Government of Jharkhand**  
*Digital India Initiative*

For support and queries: admin@jharkhand.gov.in